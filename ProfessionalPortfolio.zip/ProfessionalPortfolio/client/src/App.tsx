import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";

import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import HomePage from "@/pages/HomePage";
import AboutPage from "@/pages/AboutPage";
import ResearchPage from "@/pages/ResearchPage";
import TeachingPage from "@/pages/TeachingPage";
import PublicationsPage from "@/pages/PublicationsPage";
import ContactPage from "@/pages/ContactPage";
import OnlineLearningPage from "@/pages/OnlineLearningPage";
import CourseDetailPage from "@/pages/CourseDetailPage";
import LessonPage from "@/pages/LessonPage";
import ExamPage from "@/pages/ExamPage";
import NewsPage from "@/pages/NewsPage";
import GalleryPage from "@/pages/GalleryPage";
import LoginPage from "@/pages/LoginPage";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/research" component={ResearchPage} />
      <Route path="/teaching" component={TeachingPage} />
      <Route path="/publications" component={PublicationsPage} />
      <Route path="/contact" component={ContactPage} />
      <Route path="/online-learning" component={OnlineLearningPage} />
      <Route path="/online-learning/courses/:courseId" component={CourseDetailPage} />
      <Route path="/online-learning/courses/:courseId/lessons/:lessonId" component={LessonPage} />
      <Route path="/online-learning/courses/:courseId/exams/:examId" component={ExamPage} />
      <Route path="/news" component={NewsPage} />
      <Route path="/gallery" component={GalleryPage} />
      <Route path="/login" component={LoginPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="flex flex-col min-h-screen">
        <Header />
        <div className="flex-grow">
          <Router />
        </div>
        <Footer />
      </div>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
