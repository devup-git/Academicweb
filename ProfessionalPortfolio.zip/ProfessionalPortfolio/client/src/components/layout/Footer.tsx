import React from 'react';
import { Link } from 'wouter';
import { Linkedin, ExternalLink } from 'lucide-react';
import { FaGraduationCap, FaResearchgate } from 'react-icons/fa';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  const quickLinks = [
    { path: '/', label: 'Home' },
    { path: '/about', label: 'About' },
    { path: '/research', label: 'Research' },
    { path: '/teaching', label: 'Teaching' },
    { path: '/publications', label: 'Publications' },
    { path: '/contact', label: 'Contact' }
  ];

  return (
    <footer className="bg-neutral-800 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="text-xl font-bold font-georgia">Dr. Doosuur Dianne Ashaver</div>
            <p className="mt-2 text-neutral-300">
              Library and Information Science<br />
              Benue State University, Makurdi
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold">Quick Links</h3>
            <ul className="mt-4 space-y-2">
              {quickLinks.map(link => (
                <li key={link.path}>
                  <Link 
                    href={link.path} 
                    className="text-neutral-300 hover:text-white transition-colors duration-200"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold">Connect</h3>
            <div className="mt-4 flex space-x-4">
              <a href="#" className="text-neutral-300 hover:text-white" aria-label="LinkedIn">
                <Linkedin className="h-6 w-6" />
              </a>
              <a href="#" className="text-neutral-300 hover:text-white" aria-label="Google Scholar">
                <FaGraduationCap className="h-6 w-6" />
              </a>
              <a href="#" className="text-neutral-300 hover:text-white" aria-label="ResearchGate">
                <FaResearchgate className="h-6 w-6" />
              </a>
            </div>
            
            <h3 className="text-lg font-semibold mt-6">Benue State University</h3>
            <a 
              href="https://www.bsum.edu.ng" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="mt-2 inline-block text-neutral-300 hover:text-white transition-colors duration-200 flex items-center gap-1"
            >
              www.bsum.edu.ng
              <ExternalLink className="h-4 w-4" />
            </a>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-neutral-700 text-center text-neutral-400">
          <p>&copy; {currentYear} Dr. Doosuur Dianne Ashaver. All rights reserved.</p>
          <p className="mt-1">Designed for Benue State University</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
