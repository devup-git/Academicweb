import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Menu } from 'lucide-react';
import { cn } from '@/lib/utils';

const Header: React.FC = () => {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const navItems = [
    { path: '/', label: 'Home' },
    { path: '/about', label: 'About' },
    { path: '/research', label: 'Research' },
    { path: '/teaching', label: 'Teaching' },
    { path: '/publications', label: 'Publications' },
    { path: '/online-learning', label: 'Learning Portal' },
    { path: '/news', label: 'News' },
    { path: '/gallery', label: 'Gallery' },
    { path: '/contact', label: 'Contact' }
  ];

  return (
    <header className="bg-white border-b border-neutral-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4 md:justify-start md:space-x-10">
          <div className="flex justify-start lg:w-0 lg:flex-1">
            <Link href="/" className="flex items-center">
              <span className="text-[#0B6623] font-georgia font-bold text-xl md:text-2xl">Dr. Doosuur Dianne Ashaver</span>
            </Link>
          </div>
          
          <div className="-mr-2 -my-2 md:hidden">
            <button 
              type="button" 
              className="bg-white rounded-md p-2 inline-flex items-center justify-center text-neutral-400 hover:text-neutral-500 hover:bg-neutral-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-[#0B6623]"
              onClick={toggleMobileMenu}
            >
              <span className="sr-only">Open menu</span>
              <Menu className="h-6 w-6" />
            </button>
          </div>
          
          <nav className="hidden md:flex space-x-10">
            {navItems.map(item => (
              <Link 
                key={item.path} 
                href={item.path}
                className={cn(
                  "relative px-3 py-2 font-medium hover:text-[#0B6623] after:content-[''] after:absolute after:w-0 after:h-0.5 after:bottom-[-2px] after:left-0 after:bg-[#0B6623] after:transition-all after:duration-300 hover:after:w-full",
                  location === item.path 
                    ? "text-neutral-900 after:w-full" 
                    : "text-neutral-500"
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      </div>
      
      {/* Mobile menu */}
      <div className={`md:hidden ${mobileMenuOpen ? 'block' : 'hidden'}`}>
        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
          {navItems.map(item => (
            <Link 
              key={item.path} 
              href={item.path}
              className={cn(
                "block px-3 py-2 text-base font-medium rounded-md",
                location === item.path 
                  ? "text-neutral-900 bg-neutral-100" 
                  : "text-neutral-500 hover:text-neutral-900 hover:bg-neutral-50"
              )}
              onClick={() => setMobileMenuOpen(false)}
            >
              {item.label}
            </Link>
          ))}
        </div>
      </div>
    </header>
  );
};

export default Header;
