import { FeaturedItem, ResearchArea, Course, Publication, Resource } from "@/types";

// Featured Items for the homepage
export const featuredItems: FeaturedItem[] = [
  {
    id: 1,
    title: "Latest Paper",
    description: "Digital Preservation in Nigerian Academic Libraries: Challenges and Opportunities",
    icon: "description",
    linkText: "Read More",
    linkUrl: "/publications"
  },
  {
    id: 2,
    title: "Current Courses",
    description: "Information on courses taught this semester at Benue State University",
    icon: "school",
    linkText: "View Courses",
    linkUrl: "/teaching"
  },
  {
    id: 3,
    title: "Research Project",
    description: "Preserving Indigenous Knowledge in Benue State: A Digital Approach",
    icon: "lightbulb",
    linkText: "Learn More",
    linkUrl: "/research"
  }
];

// Research Areas
export const researchAreas: ResearchArea[] = [
  {
    id: 1,
    title: "Information Management",
    description: "Exploring efficient systems for organizing, retrieving, and preserving information in academic and public libraries.",
    icon: "storage",
    topics: [
      "Information organization frameworks",
      "Metadata standards in Nigerian contexts",
      "Knowledge management practices"
    ]
  },
  {
    id: 2,
    title: "Digital Libraries",
    description: "Researching the development, implementation, and usage of digital library systems in academic environments.",
    icon: "computer",
    topics: [
      "Digital collection management",
      "User experience in digital library interfaces",
      "Institutional repositories"
    ]
  },
  {
    id: 3,
    title: "Open Access",
    description: "Studying the implementation and impact of open access initiatives in Nigerian academic research and publishing.",
    icon: "public",
    topics: [
      "Open access policy development",
      "Barriers to open access in Nigeria",
      "Sustainable open access models"
    ]
  }
];

// Courses
export const courses: Course[] = [
  {
    id: 1,
    code: "LIS 201",
    title: "Cataloguing and Classification",
    description: "An introduction to the principles and practices of organizing library materials through cataloguing and classification systems.",
    semester: "Fall 2023",
    schedule: "Mondays & Wednesdays, 10:00am - 12:00pm",
    syllabusLink: "/api/downloads/LIS201_Syllabus.pdf",
    materialsLink: "/api/downloads/LIS201_Materials.zip"
  },
  {
    id: 2,
    code: "LIS 305",
    title: "Digital Libraries",
    description: "Study of digital library concepts, technologies, and management, with emphasis on digitization, metadata, and access systems.",
    semester: "Fall 2023",
    schedule: "Tuesdays & Thursdays, 2:00pm - 4:00pm",
    syllabusLink: "/api/downloads/LIS305_Syllabus.pdf",
    materialsLink: "/api/downloads/LIS305_Materials.zip"
  },
  {
    id: 3,
    code: "LIS 410",
    title: "Information Management",
    description: "Advanced course covering information lifecycle management, knowledge organization, and information governance.",
    semester: "Spring 2024",
    schedule: "Wednesdays & Fridays, 9:00am - 11:00am",
    syllabusLink: "/api/downloads/LIS410_Syllabus.pdf",
    materialsLink: "/api/downloads/LIS410_Materials.zip"
  }
];

// Publications
export const publications: Publication[] = [
  {
    id: 1,
    title: "Digital Preservation in Nigerian Academic Libraries: Challenges and Opportunities",
    year: 2023,
    authors: "Ashaver, D.D., Okonkwo, E.C., & Nwachukwu, V.N.",
    venue: "Journal of Academic Librarianship",
    description: "This study examines the current state of digital preservation practices in Nigerian academic libraries, identifying key challenges and proposing strategic approaches for improvement.",
    tags: ["Digital Libraries", "Academic Libraries", "Nigeria"],
    pdfLink: "/api/downloads/Digital_Preservation_Nigeria.pdf",
    doiLink: "https://doi.org/10.1000/xyz123",
    citationCount: 12
  },
  {
    id: 2,
    title: "Information Literacy Skills Among Undergraduate Students: A Case Study of Benue State University",
    year: 2022,
    authors: "Ashaver, D.D. & Igyuve, S.M.",
    venue: "International Journal of Library and Information Science",
    description: "This research assesses the information literacy competencies of undergraduate students at Benue State University, highlighting gaps and recommending targeted interventions for improvement.",
    tags: ["Information Literacy", "Higher Education", "Nigeria"],
    pdfLink: "/api/downloads/Information_Literacy_BSU.pdf",
    doiLink: "https://doi.org/10.1000/abc456",
    citationCount: 8
  },
  {
    id: 3,
    title: "Open Access Publishing in Nigeria: Adoption Patterns and Policy Implications",
    year: 2021,
    authors: "Ashaver, D.D.",
    venue: "Journal of Scholarly Publishing",
    description: "This paper analyzes trends in open access publishing among Nigerian academics, examining factors influencing adoption and proposing policy frameworks to enhance open access initiatives.",
    tags: ["Open Access", "Scholarly Publishing", "Nigeria"],
    pdfLink: "/api/downloads/Open_Access_Nigeria.pdf",
    doiLink: "https://doi.org/10.1000/def789",
    citationCount: 15
  },
  {
    id: 4,
    title: "Library Automation in Nigeria: Current Status, Challenges, and Future Directions",
    year: 2023,
    authors: "Ashaver, D.D. & Terna, R.A.",
    venue: "African Journal of Library, Archives and Information Science",
    description: "A comprehensive assessment of library automation systems in Nigerian academic institutions, examining implementation challenges and proposing sustainable automation strategies.",
    tags: ["Library Automation", "Academic Libraries", "Nigeria", "Information Technology"],
    pdfLink: "/api/downloads/Library_Automation_Nigeria.pdf",
    doiLink: "https://doi.org/10.1000/ghi123",
    citationCount: 6
  },
  {
    id: 5,
    title: "Preserving Indigenous Knowledge in Nigerian Libraries: A Digital Approach",
    year: 2022,
    authors: "Ashaver, D.D., Bako, A.A., & James, T.E.",
    venue: "Journal of Documentation",
    description: "This research explores methodologies for documenting, preserving, and promoting indigenous knowledge through digital libraries in Nigeria, with a specific focus on oral traditions and cultural practices.",
    tags: ["Indigenous Knowledge", "Digital Preservation", "Cultural Heritage", "Nigeria"],
    pdfLink: "/api/downloads/Indigenous_Knowledge_Nigeria.pdf",
    doiLink: "https://doi.org/10.1000/jkl456",
    citationCount: 11
  },
  {
    id: 6,
    title: "Information Needs and Seeking Behavior of Faculty Members at Benue State University",
    year: 2021,
    authors: "Ashaver, D.D. & Mngutyo, J.N.",
    venue: "Library Philosophy and Practice",
    description: "An investigation into how faculty members at Benue State University access, evaluate, and utilize information resources for teaching and research purposes.",
    tags: ["Information Behavior", "Academic Libraries", "Higher Education", "Faculty"],
    pdfLink: "/api/downloads/Faculty_Information_Needs.pdf",
    doiLink: "https://doi.org/10.1000/mno789",
    citationCount: 9
  },
  {
    id: 7,
    title: "Mobile Technologies in Academic Libraries: Use Cases from Nigerian Universities",
    year: 2020,
    authors: "Ashaver, D.D.",
    venue: "International Information & Library Review",
    description: "This study examines the adoption and application of mobile technologies in Nigerian academic libraries, highlighting innovative services and recommendations for implementation.",
    tags: ["Mobile Technology", "Academic Libraries", "Nigeria", "Information Technology"],
    pdfLink: "/api/downloads/Mobile_Technologies_Libraries.pdf",
    doiLink: "https://doi.org/10.1000/pqr321",
    citationCount: 14
  },
  {
    id: 8,
    title: "Collaborative Research in Library and Information Science: A Bibliometric Analysis of Co-authorship Patterns in Nigeria",
    year: 2019,
    authors: "Ashaver, D.D. & Iorver, O.M.",
    venue: "Scientometrics",
    description: "A bibliometric analysis of co-authorship trends among Library and Information Science researchers in Nigeria, identifying patterns, productivity, and collaboration networks.",
    tags: ["Bibliometrics", "Scholarly Publishing", "Research Collaboration", "Nigeria"],
    pdfLink: "/api/downloads/Collaboration_Bibliometrics.pdf",
    doiLink: "https://doi.org/10.1000/stu654",
    citationCount: 7
  }
];

// Resources
export const resources: Resource[] = [
  {
    id: 1,
    title: "Introduction to MARC Standards",
    description: "A comprehensive guide to understanding and applying MARC21 formats in cataloguing.",
    type: "student",
    icon: "description",
    link: "/api/downloads/MARC_Standards_Guide.pdf"
  },
  {
    id: 2,
    title: "Citation Guidelines",
    description: "A guide to APA, MLA, and Chicago citation styles for academic papers and research.",
    type: "student",
    icon: "description",
    link: "/api/downloads/Citation_Guidelines.pdf"
  },
  {
    id: 3,
    title: "Research Methodology Handbook",
    description: "A comprehensive guide to research methods in Library and Information Science.",
    type: "student",
    icon: "description",
    link: "/api/downloads/Research_Methodology.pdf"
  },
  {
    id: 4,
    title: "Zotero",
    description: "A free tool to help you collect, organize, cite, and share research.",
    type: "tool",
    icon: "link",
    link: "https://www.zotero.org/",
    isExternal: true
  },
  {
    id: 5,
    title: "DSpace",
    description: "An open source repository software for digital archives and institutional repositories.",
    type: "tool",
    icon: "link",
    link: "https://duraspace.org/dspace/",
    isExternal: true
  },
  {
    id: 6,
    title: "BSU Library Catalog",
    description: "Access the Benue State University Library catalog for research materials.",
    type: "tool",
    icon: "link",
    link: "#",
    isExternal: true
  }
];
