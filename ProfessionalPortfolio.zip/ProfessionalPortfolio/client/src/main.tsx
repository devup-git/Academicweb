import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add custom font and material icon styles
const linkGoogleFonts = document.createElement("link");
linkGoogleFonts.href = "https://fonts.googleapis.com/css2?family=Georgia:wght@400;700&family=Inter:wght@300;400;500;600;700&display=swap";
linkGoogleFonts.rel = "stylesheet";
document.head.appendChild(linkGoogleFonts);

const linkMaterialIcons = document.createElement("link");
linkMaterialIcons.href = "https://fonts.googleapis.com/icon?family=Material+Icons";
linkMaterialIcons.rel = "stylesheet";
document.head.appendChild(linkMaterialIcons);

// Set page title
document.title = "Dr. Doosuur Dianne Ashaver | Library and Information Science";

// Add custom tailwind styles for BSU colors
const styleElement = document.createElement("style");
styleElement.textContent = `
  @tailwind base;
  @tailwind components;
  @tailwind utilities;
  
  .font-georgia {
    font-family: 'Georgia', serif;
  }
  
  :root {
    --bsu-green: #0B6623;
    --bsu-green-light: #3a8c49;
    --bsu-green-dark: #094d1c;
  }
  
  .text-bsu-green {
    color: var(--bsu-green);
  }
  
  .bg-bsu-green {
    background-color: var(--bsu-green);
  }
  
  .hover\\:bg-bsu-green:hover {
    background-color: var(--bsu-green);
  }
  
  .hover\\:text-bsu-green:hover {
    color: var(--bsu-green);
  }
  
  .border-bsu-green {
    border-color: var(--bsu-green);
  }
`;
document.head.appendChild(styleElement);

createRoot(document.getElementById("root")!).render(<App />);
