import React from 'react';
import { Download } from 'lucide-react';
import { Button } from '@/components/ui/button';

const AboutPage: React.FC = () => {
  return (
    <section id="about" className="py-16 bg-neutral-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold font-georgia text-neutral-900">About Me</h2>
            <div className="mt-6 space-y-4 text-neutral-700">
              <p>
                I am a Doctor of Library and Information Science and lecturer at Benue State University, Makurdi. My academic journey has been dedicated to the advancement of information management practices, digital archiving, and library sciences.
              </p>
              <p>
                With over a decade of experience in the field, my research interests include digital preservation, information literacy, open access initiatives, and the application of emerging technologies in library systems.
              </p>
              <p>
                At Benue State University, I teach courses in cataloguing, classification, information management, and digital library systems while mentoring the next generation of library and information science professionals.
              </p>
            </div>
            
            <div className="mt-8">
              <Button
                className="inline-flex items-center bg-[#0B6623] hover:bg-[#094d1c] text-white"
                onClick={() => window.open('/api/downloads/CV_DrAshaver.pdf')}
              >
                <Download className="mr-2 h-4 w-4" />
                Download CV
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="aspect-square">
              <img 
                className="w-full h-full object-cover rounded-lg shadow-md" 
                src="https://images.unsplash.com/photo-1523050854058-8df90110c9f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                alt="University library reading area"
              />
            </div>
            <div className="aspect-square mt-8">
              <img 
                className="w-full h-full object-cover rounded-lg shadow-md" 
                src="https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                alt="Library archive shelves" 
              />
            </div>
            <div className="aspect-square">
              <img 
                className="w-full h-full object-cover rounded-lg shadow-md" 
                src="https://images.unsplash.com/photo-1521587760476-6c12a4b040da?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                alt="Student consulting books in library" 
              />
            </div>
            <div className="aspect-square mt-8">
              <img 
                className="w-full h-full object-cover rounded-lg shadow-md" 
                src="https://images.unsplash.com/photo-1497633762265-9d179a990aa6?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                alt="Stack of books and digital tablet" 
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutPage;
