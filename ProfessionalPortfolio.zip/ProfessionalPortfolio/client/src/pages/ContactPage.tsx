import React, { useState } from 'react';
import { Mail, MapPin, Clock } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { ContactFormData } from '@/types';
import { apiRequest } from '@/lib/queryClient';

const ContactPage: React.FC = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.name || !formData.email || !formData.subject || !formData.message) {
      toast({
        title: "Form incomplete",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const response = await apiRequest('POST', '/api/contact', formData);
      const data = await response.json();
      
      toast({
        title: "Message sent",
        description: data.message,
        variant: "default"
      });
      
      // Reset form
      setFormData({
        name: '',
        email: '',
        subject: '',
        message: ''
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem sending your message. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold font-georgia text-neutral-900">Contact</h2>
        <p className="mt-4 text-lg text-neutral-600">
          Get in touch with me for academic inquiries, research collaboration, or student matters.
        </p>
        
        <div className="mt-10 grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <h3 className="text-xl font-semibold font-georgia text-neutral-900">Send a Message</h3>
            <form className="mt-6 grid grid-cols-1 gap-y-6" onSubmit={handleSubmit}>
              <div>
                <Label htmlFor="name">Name</Label>
                <div className="mt-1">
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Your name"
                    required
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <div className="mt-1">
                  <Input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="your.email@example.com"
                    required
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="subject">Subject</Label>
                <div className="mt-1">
                  <Input
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    placeholder="What is your message about?"
                    required
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="message">Message</Label>
                <div className="mt-1">
                  <Textarea
                    id="message"
                    name="message"
                    rows={4}
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Your message"
                    required
                  />
                </div>
              </div>
              <div>
                <Button 
                  type="submit" 
                  className="bg-yellow-500 hover:bg-yellow-400 text-black px-6 py-3 font-medium"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Sending..." : "Send Message"}
                </Button>
              </div>
            </form>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold font-georgia text-neutral-900">Contact Information</h3>
            <div className="mt-6 space-y-6">
              <div className="flex items-start">
                <div className="flex-shrink-0 mt-1">
                  <Mail className="h-5 w-5 text-[#0B6623]" />
                </div>
                <div className="ml-3">
                  <h4 className="text-sm font-medium text-neutral-900">Email</h4>
                  <p className="mt-1 text-neutral-700">
                    <a href="mailto:doosuur.ashaver@bsum.edu.ng" className="text-[#0B6623] hover:text-[#094d1c]">
                      doosuur.ashaver@bsum.edu.ng
                    </a>
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0 mt-1">
                  <MapPin className="h-5 w-5 text-[#0B6623]" />
                </div>
                <div className="ml-3">
                  <h4 className="text-sm font-medium text-neutral-900">Office</h4>
                  <p className="mt-1 text-neutral-700">
                    Faculty of Education Building, Room 245<br />
                    Benue State University<br />
                    Makurdi, Benue State, Nigeria
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0 mt-1">
                  <Clock className="h-5 w-5 text-[#0B6623]" />
                </div>
                <div className="ml-3">
                  <h4 className="text-sm font-medium text-neutral-900">Office Hours</h4>
                  <p className="mt-1 text-neutral-700">
                    Monday: 1:00pm - 3:00pm<br />
                    Thursday: 10:00am - 12:00pm<br />
                    Or by appointment
                  </p>
                </div>
              </div>
            </div>
            
            <div className="mt-8">
              <h3 className="text-xl font-semibold font-georgia text-neutral-900">Location</h3>
              <Card className="mt-4 bg-neutral-200 rounded-lg h-64">
                <CardContent className="w-full h-full flex items-center justify-center text-neutral-600 rounded-lg p-0">
                  <div className="text-center p-4">
                    <MapPin className="mx-auto h-12 w-12" />
                    <p className="mt-2">Google Maps embed of Benue State University</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactPage;
