import React, { useState } from 'react';
import { useRoute, Link } from 'wouter';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Calendar, 
  Book, 
  Video, 
  FileText, 
  Users, 
  Clock, 
  PlayCircle, 
  CheckCircle, 
  BookOpen, 
  LockIcon,
  PencilIcon,
  FileDown,
  Presentation,
  GraduationCap,
  AlertCircle,
  ChevronLeft
} from 'lucide-react';
import { courses } from '@/lib/data';

// Mock lesson data
const courseLessons = [
  {
    id: 1,
    title: 'Introduction to Digital Libraries',
    description: 'Overview of digital libraries and their importance in modern society',
    type: 'lecture',
    duration: 60, // minutes
    videoUrl: '/path/to/video',
    isCompleted: true,
    materials: ['Lecture Slides', 'Reading: Evolution of Digital Libraries', 'Reference Links'],
    date: new Date('2023-11-10')
  },
  {
    id: 2,
    title: 'Digital Library Architecture',
    description: 'Exploring the technical architecture of digital library systems',
    type: 'lecture',
    duration: 75,
    videoUrl: '/path/to/video',
    isCompleted: true,
    materials: ['Lecture Slides', 'Architecture Diagrams', 'Case Study'],
    date: new Date('2023-11-17')
  },
  {
    id: 3,
    title: 'Metadata Standards',
    description: 'Introduction to metadata standards and practices in digital libraries',
    type: 'lecture',
    duration: 60,
    videoUrl: '/path/to/video',
    isCompleted: false,
    materials: ['Lecture Slides', 'Reading: Dublin Core', 'Metadata Exercise'],
    date: new Date('2023-11-24')
  },
  {
    id: 4,
    title: 'Mid-term Examination',
    description: 'Assessment covering digital library concepts, architecture, and metadata',
    type: 'exam',
    duration: 120,
    isCompleted: false,
    date: new Date('2023-12-01')
  },
  {
    id: 5,
    title: 'Digital Preservation Strategies',
    description: 'Understanding approaches to long-term digital preservation',
    type: 'lecture',
    duration: 70,
    videoUrl: '/path/to/video',
    isCompleted: false,
    materials: ['Lecture Slides', 'Preservation Case Studies', 'Group Activity Instructions'],
    date: new Date('2023-12-08')
  },
  {
    id: 6,
    title: 'Interactive Workshop: Digital Collection Development',
    description: 'Hands-on workshop for developing a digital collection project',
    type: 'workshop',
    duration: 120,
    isCompleted: false,
    materials: ['Workshop Guide', 'Project Template', 'Resources List'],
    date: new Date('2023-12-15')
  }
];

// Mock exam data
const courseExams = [
  {
    id: 101,
    title: 'Mid-term Examination',
    description: 'Assessment covering digital library concepts, architecture, and metadata',
    duration: 120, // minutes
    questionCount: 40,
    availableFrom: new Date('2023-12-01T09:00:00'),
    availableTo: new Date('2023-12-01T16:00:00'),
    status: 'upcoming', // upcoming, available, completed
    score: null
  },
  {
    id: 102,
    title: 'Final Examination',
    description: 'Comprehensive assessment of all course material',
    duration: 180,
    questionCount: 60,
    availableFrom: new Date('2024-01-05T09:00:00'),
    availableTo: new Date('2024-01-05T16:00:00'),
    status: 'upcoming',
    score: null
  },
  {
    id: 103,
    title: 'Quiz: Digital Preservation',
    description: 'Short quiz on digital preservation concepts',
    duration: 30,
    questionCount: 15,
    availableFrom: new Date('2023-12-10T00:00:00'),
    availableTo: new Date('2023-12-17T23:59:59'),
    status: 'upcoming',
    score: null
  }
];

// Mock course materials
const courseMaterials = [
  {
    id: 201,
    title: 'Course Syllabus',
    description: 'Complete syllabus and course expectations',
    type: 'document',
    fileSize: '420KB',
    uploadDate: new Date('2023-11-05'),
    downloadUrl: '/path/to/syllabus.pdf'
  },
  {
    id: 202,
    title: 'Digital Libraries Textbook',
    description: 'Primary textbook for the course (PDF)',
    type: 'book',
    fileSize: '12.4MB', 
    uploadDate: new Date('2023-11-05'),
    downloadUrl: '/path/to/textbook.pdf'
  },
  {
    id: 203,
    title: 'Lecture 1: Introduction Slides',
    description: 'Slide deck for the introductory lecture',
    type: 'presentation',
    fileSize: '3.2MB',
    uploadDate: new Date('2023-11-09'),
    downloadUrl: '/path/to/lecture1.pptx'
  },
  {
    id: 204,
    title: 'Lecture 2: Architecture Slides',
    description: 'Slide deck covering digital library architecture',
    type: 'presentation',
    fileSize: '4.8MB',
    uploadDate: new Date('2023-11-16'),
    downloadUrl: '/path/to/lecture2.pptx'
  },
  {
    id: 205,
    title: 'Lecture 3: Metadata Standards Slides',
    description: 'Slide deck on metadata standards and practices',
    type: 'presentation',
    fileSize: '3.6MB',
    uploadDate: new Date('2023-11-23'),
    downloadUrl: '/path/to/lecture3.pptx'
  },
  {
    id: 206,
    title: 'Supplementary Reading: Evolution of Digital Libraries',
    description: 'Journal article on the historical development of digital libraries',
    type: 'document',
    fileSize: '1.8MB',
    uploadDate: new Date('2023-11-09'),
    downloadUrl: '/path/to/reading1.pdf'
  },
  {
    id: 207,
    title: 'Supplementary Reading: Dublin Core Metadata',
    description: 'Comprehensive guide to Dublin Core metadata standards',
    type: 'document',
    fileSize: '2.4MB',
    uploadDate: new Date('2023-11-23'),
    downloadUrl: '/path/to/reading2.pdf'
  }
];

// Mock student progress (percentage complete)
const studentProgress = 32;

const CourseDetailPage: React.FC = () => {
  const [, params] = useRoute<{ courseId: string }>('/online-learning/courses/:courseId');
  const courseId = parseInt(params?.courseId || '1');

  const [activeTab, setActiveTab] = useState('overview');
  
  // Find the current course
  const course = courses.find(c => c.id === courseId) || courses[0];
  
  // Format dates in a readable form
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric', 
      month: 'long', 
      day: 'numeric'
    }).format(date);
  };
  
  // Format time for exam schedules
  const formatTime = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      hour: 'numeric',
      minute: 'numeric',
      hour12: true
    }).format(date);
  };
  
  // Get icon for lesson type
  const getLessonTypeIcon = (type: string) => {
    switch (type) {
      case 'lecture':
        return <Video className="h-4 w-4 text-blue-500" />;
      case 'workshop':
        return <Users className="h-4 w-4 text-purple-500" />;
      case 'exam':
        return <PencilIcon className="h-4 w-4 text-red-500" />;
      default:
        return <Book className="h-4 w-4 text-neutral-500" />;
    }
  };
  
  // Get icon for material type
  const getMaterialTypeIcon = (type: string) => {
    switch (type) {
      case 'document':
        return <FileText className="h-4 w-4 text-blue-500" />;
      case 'book':
        return <BookOpen className="h-4 w-4 text-green-500" />;
      case 'presentation':
        return <Presentation className="h-4 w-4 text-amber-500" />;
      default:
        return <FileText className="h-4 w-4 text-neutral-500" />;
    }
  };
  
  return (
    <div className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div>
            <Link href="/online-learning">
              <Button variant="ghost" className="pl-0 mb-2 text-neutral-500 hover:text-neutral-700">
                <ChevronLeft className="mr-1 h-4 w-4" />
                Back to Courses
              </Button>
            </Link>
            <h1 className="text-3xl font-bold font-georgia text-neutral-900">{course.title}</h1>
            <div className="flex flex-wrap items-center gap-3 mt-2">
              <Badge variant="outline" className="bg-white">
                {course.code}
              </Badge>
              <Badge variant="green">{course.semester}</Badge>
              <div className="text-sm text-neutral-500 flex items-center">
                <Calendar className="h-4 w-4 mr-1" />
                {course.schedule}
              </div>
            </div>
          </div>
          
          <div className="space-x-3">
            <Button 
              variant="outline" 
              className="border-[#0B6623] text-[#0B6623] hover:bg-[#0B6623]/10"
              onClick={() => window.open(course.syllabusLink, '_blank')}
            >
              <FileDown className="mr-2 h-4 w-4" />
              Syllabus
            </Button>
            <Button 
              className="bg-[#0B6623] hover:bg-[#094d1c]"
              onClick={() => window.open(course.materialsLink, '_blank')}
            >
              <PlayCircle className="mr-2 h-4 w-4" />
              Start Learning
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-12 gap-6">
          {/* Main Content */}
          <div className="col-span-12 lg:col-span-8">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="w-full grid grid-cols-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="lessons">Lessons</TabsTrigger>
                <TabsTrigger value="materials">Materials</TabsTrigger>
                <TabsTrigger value="exams">Exams</TabsTrigger>
              </TabsList>
              
              {/* Overview Tab */}
              <TabsContent value="overview" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Course Description</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-neutral-700">{course.description}</p>
                    
                    <div className="mt-8">
                      <h3 className="font-semibold text-lg mb-4">Learning Objectives</h3>
                      <ul className="space-y-2">
                        <li className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-[#0B6623] mr-2 flex-shrink-0 mt-0.5" />
                          <span>Understand the fundamental concepts and principles of digital libraries</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-[#0B6623] mr-2 flex-shrink-0 mt-0.5" />
                          <span>Analyze the architecture and technical infrastructure of digital libraries</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-[#0B6623] mr-2 flex-shrink-0 mt-0.5" />
                          <span>Apply metadata standards for organizing digital collections</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-[#0B6623] mr-2 flex-shrink-0 mt-0.5" />
                          <span>Develop strategies for digital preservation and long-term access</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-[#0B6623] mr-2 flex-shrink-0 mt-0.5" />
                          <span>Create a prototype digital collection using appropriate tools and standards</span>
                        </li>
                      </ul>
                    </div>
                    
                    <div className="mt-8">
                      <h3 className="font-semibold text-lg mb-4">Course Requirements</h3>
                      <div className="grid md:grid-cols-2 gap-4">
                        <Card className="bg-neutral-50">
                          <CardContent className="p-4">
                            <h4 className="font-medium flex items-center">
                              <GraduationCap className="h-4 w-4 mr-2 text-neutral-700" />
                              Grading Breakdown
                            </h4>
                            <ul className="mt-2 space-y-1 text-sm text-neutral-700">
                              <li className="flex justify-between">
                                <span>Attendance & Participation</span>
                                <span>10%</span>
                              </li>
                              <li className="flex justify-between">
                                <span>Assignments</span>
                                <span>25%</span>
                              </li>
                              <li className="flex justify-between">
                                <span>Mid-term Examination</span>
                                <span>25%</span>
                              </li>
                              <li className="flex justify-between">
                                <span>Group Project</span>
                                <span>15%</span>
                              </li>
                              <li className="flex justify-between">
                                <span>Final Examination</span>
                                <span>25%</span>
                              </li>
                            </ul>
                          </CardContent>
                        </Card>
                        
                        <Card className="bg-neutral-50">
                          <CardContent className="p-4">
                            <h4 className="font-medium flex items-center">
                              <Book className="h-4 w-4 mr-2 text-neutral-700" />
                              Required Materials
                            </h4>
                            <ul className="mt-2 space-y-1 text-sm text-neutral-700">
                              <li>Digital Libraries: Principles and Practice (Smith & Johnson, 2021)</li>
                              <li>Metadata for Digital Collections (Cooper, 2019)</li>
                              <li>Access to a computer with internet connection</li>
                              <li>BSU Library electronic resources access</li>
                            </ul>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                    
                    <div className="mt-8 bg-blue-50 rounded-lg p-4 border border-blue-100">
                      <div className="flex">
                        <AlertCircle className="h-5 w-5 text-blue-500 mr-2 flex-shrink-0 mt-0.5" />
                        <div>
                          <h4 className="font-medium text-blue-800">Important Note</h4>
                          <p className="text-blue-700 text-sm mt-1">
                            This course includes both in-person and online components. Students are required to attend 
                            physical lectures on campus as scheduled, while also engaging with online materials, 
                            discussions, and assessments through this platform.
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Lessons Tab */}
              <TabsContent value="lessons" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Course Lessons</CardTitle>
                    <CardDescription>
                      All scheduled lessons and activities for {course.code}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {courseLessons.map((lesson) => (
                        <div key={lesson.id} className={`rounded-lg border p-4 transition-colors ${lesson.isCompleted ? 'bg-neutral-50' : 'bg-white'}`}>
                          <div className="flex items-start justify-between">
                            <div className="flex items-start space-x-4">
                              <div className={`mt-0.5 rounded-full p-1 ${
                                lesson.type === 'lecture' ? 'bg-blue-100' : 
                                lesson.type === 'workshop' ? 'bg-purple-100' : 'bg-red-100'
                              }`}>
                                {getLessonTypeIcon(lesson.type)}
                              </div>
                              <div>
                                <div className="flex items-center">
                                  <h3 className="font-semibold text-lg">{lesson.title}</h3>
                                  {lesson.isCompleted && (
                                    <Badge variant="outline" className="ml-2 bg-green-50 text-green-700 border-green-200">
                                      Completed
                                    </Badge>
                                  )}
                                </div>
                                <p className="text-sm text-neutral-600 mt-1">{lesson.description}</p>
                                
                                <div className="flex flex-wrap items-center gap-x-4 gap-y-2 mt-3 text-xs text-neutral-500">
                                  <div className="flex items-center">
                                    <Calendar className="h-3 w-3 mr-1" />
                                    {formatDate(lesson.date)}
                                  </div>
                                  {lesson.duration && (
                                    <div className="flex items-center">
                                      <Clock className="h-3 w-3 mr-1" />
                                      {lesson.duration} minutes
                                    </div>
                                  )}
                                  {lesson.materials && (
                                    <div className="flex items-center">
                                      <FileText className="h-3 w-3 mr-1" />
                                      {lesson.materials.length} materials
                                    </div>
                                  )}
                                </div>
                                
                                {lesson.materials && lesson.materials.length > 0 && (
                                  <div className="mt-3 flex flex-wrap gap-2">
                                    {lesson.materials.map((material, index) => (
                                      <Badge key={index} variant="outline" className="bg-white">
                                        {material}
                                      </Badge>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </div>
                            
                            <div>
                              {lesson.type === 'lecture' && lesson.videoUrl && (
                                <Button size="sm" variant="outline" className="text-[#0B6623]">
                                  <PlayCircle className="mr-1 h-4 w-4" />
                                  Watch
                                </Button>
                              )}
                              {lesson.type === 'exam' && (
                                <Button size="sm" variant="outline" className="text-red-600" disabled={new Date() < lesson.date}>
                                  <PencilIcon className="mr-1 h-4 w-4" />
                                  {new Date() < lesson.date ? 'Not Available' : 'Start Exam'}
                                </Button>
                              )}
                              {lesson.type === 'workshop' && (
                                <Button size="sm" variant="outline">
                                  <Users className="mr-1 h-4 w-4" />
                                  View Details
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Materials Tab */}
              <TabsContent value="materials" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Course Materials</CardTitle>
                    <CardDescription>
                      Access all lecture slides, readings, and additional resources
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {courseMaterials.map((material) => (
                        <div key={material.id} className="flex items-start p-4 border rounded-lg hover:bg-neutral-50 transition-colors">
                          <div className={`mt-0.5 rounded-full p-1 mr-4 ${
                            material.type === 'document' ? 'bg-blue-100' : 
                            material.type === 'book' ? 'bg-green-100' : 'bg-amber-100'
                          }`}>
                            {getMaterialTypeIcon(material.type)}
                          </div>
                          
                          <div className="flex-1">
                            <h3 className="font-semibold">{material.title}</h3>
                            <p className="text-sm text-neutral-600 mt-1">{material.description}</p>
                            
                            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-xs text-neutral-500">
                              <div className="flex items-center">
                                <Calendar className="h-3 w-3 mr-1" />
                                {formatDate(material.uploadDate)}
                              </div>
                              <div className="flex items-center">
                                <FileText className="h-3 w-3 mr-1" />
                                {material.fileSize}
                              </div>
                              <Badge variant="outline" className="capitalize">
                                {material.type}
                              </Badge>
                            </div>
                          </div>
                          
                          <div>
                            <Button size="sm" variant="outline" className="text-[#0B6623]">
                              <FileDown className="mr-1 h-4 w-4" />
                              Download
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Exams Tab */}
              <TabsContent value="exams" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Exams & Assessments</CardTitle>
                    <CardDescription>
                      Scheduled exams, quizzes, and assessments for this course
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {courseExams.map((exam) => (
                        <Card key={exam.id} className="overflow-hidden">
                          <CardHeader className={`pb-3 ${
                            exam.status === 'available' ? 'bg-green-50' : 
                            exam.status === 'completed' ? 'bg-blue-50' : 'bg-neutral-50'
                          }`}>
                            <div className="flex justify-between items-start">
                              <CardTitle className="text-lg">{exam.title}</CardTitle>
                              <Badge variant={
                                exam.status === 'available' ? 'green' : 
                                exam.status === 'completed' ? 'blue' : 'outline'
                              }>
                                {exam.status === 'available' ? 'Available Now' : 
                                exam.status === 'completed' ? 'Completed' : 'Upcoming'}
                              </Badge>
                            </div>
                            <CardDescription>{exam.description}</CardDescription>
                          </CardHeader>
                          
                          <CardContent className="pt-4">
                            <div className="grid md:grid-cols-3 gap-4 text-sm">
                              <div>
                                <div className="text-neutral-500 mb-1">Available From</div>
                                <div className="font-medium">{formatDate(exam.availableFrom)}</div>
                                <div>{formatTime(exam.availableFrom)}</div>
                              </div>
                              
                              <div>
                                <div className="text-neutral-500 mb-1">Available Until</div>
                                <div className="font-medium">{formatDate(exam.availableTo)}</div>
                                <div>{formatTime(exam.availableTo)}</div>
                              </div>
                              
                              <div>
                                <div className="text-neutral-500 mb-1">Duration</div>
                                <div className="font-medium">{exam.duration} minutes</div>
                                <div>{exam.questionCount} questions</div>
                              </div>
                            </div>
                            
                            {exam.status === 'completed' && exam.score !== null && (
                              <div className="mt-4 bg-blue-50 p-3 rounded-md">
                                <div className="font-medium text-blue-800 mb-1">Your Score</div>
                                <div className="text-2xl font-bold text-blue-700">{exam.score}%</div>
                              </div>
                            )}
                          </CardContent>
                          
                          <CardFooter className="border-t bg-neutral-50 flex justify-between">
                            <div className="text-sm text-neutral-500">
                              {exam.status === 'upcoming' && new Date() < exam.availableFrom && (
                                <span>Opens in {Math.ceil((exam.availableFrom.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days</span>
                              )}
                              {exam.status === 'available' && (
                                <span>Closes in {Math.ceil((exam.availableTo.getTime() - new Date().getTime()) / (1000 * 60 * 60))} hours</span>
                              )}
                              {exam.status === 'completed' && (
                                <span>Completed on {formatDate(exam.availableTo)}</span>
                              )}
                            </div>
                            
                            <Button 
                              variant={exam.status === 'available' ? 'default' : 'outline'}
                              size="sm"
                              disabled={exam.status !== 'available'}
                              className={exam.status === 'available' ? 'bg-[#0B6623] hover:bg-[#094d1c]' : ''}
                            >
                              {exam.status === 'available' ? 'Start Exam' : 
                               exam.status === 'completed' ? 'View Results' : 'Not Available'}
                            </Button>
                          </CardFooter>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
          
          {/* Sidebar */}
          <div className="col-span-12 lg:col-span-4">
            <div className="space-y-6">
              {/* Progress Card */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Your Progress</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center mb-2">
                    <span className="text-3xl font-bold text-[#0B6623]">{studentProgress}%</span>
                    <span className="text-neutral-500 text-sm ml-2">Complete</span>
                  </div>
                  <Progress value={studentProgress} className="h-2" />
                  
                  <div className="mt-6 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-neutral-600">Lessons Completed</span>
                      <span className="font-medium">2/6</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-neutral-600">Materials Accessed</span>
                      <span className="font-medium">5/7</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-neutral-600">Exams Completed</span>
                      <span className="font-medium">0/3</span>
                    </div>
                  </div>
                  
                  <Button className="w-full mt-6 bg-[#0B6623] hover:bg-[#094d1c]">
                    Continue Learning
                  </Button>
                </CardContent>
              </Card>
              
              {/* Instructor Card */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Instructor</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center">
                    <Avatar className="h-12 w-12">
                      <AvatarFallback className="bg-[#0B6623]/10 text-[#0B6623]">DA</AvatarFallback>
                    </Avatar>
                    <div className="ml-4">
                      <div className="font-medium">Dr. Doosuur Dianne Ashaver</div>
                      <div className="text-sm text-neutral-500">Associate Professor</div>
                    </div>
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <div className="text-sm">
                    <div className="font-medium mb-2">Contact Information</div>
                    <div className="space-y-1 text-neutral-600">
                      <div>Office: Library Science Building, Room 205</div>
                      <div>Office Hours: Mondays & Wednesdays, 2-4 PM</div>
                      <div>Email: d.ashaver@bsu.edu.ng</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Class Information */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Class Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="font-medium mb-1">Schedule</div>
                    <div className="text-sm text-neutral-600">{course.schedule}</div>
                  </div>
                  
                  <div>
                    <div className="font-medium mb-1">Location</div>
                    <div className="text-sm text-neutral-600">Library Science Building, Room 105</div>
                  </div>
                  
                  <div>
                    <div className="font-medium mb-1">Semester</div>
                    <div className="text-sm text-neutral-600">{course.semester}</div>
                  </div>
                  
                  <div>
                    <div className="font-medium mb-1">Enrolled Students</div>
                    <div className="text-sm text-neutral-600">25 students</div>
                  </div>
                  
                  <div className="pt-2 space-y-3">
                    <Button variant="outline" className="w-full">
                      <LockIcon className="mr-2 h-4 w-4" />
                      Enter Class Code
                    </Button>
                    <Button className="w-full bg-yellow-500 text-black hover:bg-yellow-400">
                      Contact Instructor
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseDetailPage;