import React, { useState } from 'react';
import { useRoute, Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { 
  ChevronLeft, 
  ChevronRight, 
  Clock, 
  AlertCircle, 
  CheckCircle, 
  XCircle,
  HelpCircle
} from 'lucide-react';
import { courses } from '@/lib/data';

// Mock exam data
const examData = {
  id: 101,
  courseId: 1,
  title: 'Mid-term Examination',
  description: 'Assessment covering digital library concepts, architecture, and metadata',
  duration: 120, // minutes
  totalQuestions: 10,
  passingScore: 60,
  instructions: [
    'Read each question carefully before answering.',
    'This exam contains multiple choice and short answer questions.',
    'You have 120 minutes to complete this exam.',
    'You can navigate between questions using the Next and Previous buttons.',
    'Your answers are saved automatically after each question.',
    'Submit your exam only when you have reviewed all answers.'
  ],
  questions: [
    {
      id: 1,
      type: 'multiple_choice',
      text: 'Which of the following best describes the primary purpose of a digital library?',
      options: [
        'To replace physical libraries entirely',
        'To collect, organize, preserve, and provide access to digital resources',
        'To digitize all existing print materials',
        'To reduce the cost of library operations'
      ],
      correctAnswer: 1 // index of correct answer
    },
    {
      id: 2,
      type: 'multiple_choice',
      text: 'Which layer in the three-tier digital library architecture is responsible for user interaction?',
      options: [
        'Data layer',
        'Application layer',
        'Presentation layer',
        'Storage layer'
      ],
      correctAnswer: 2
    },
    {
      id: 3,
      type: 'multiple_choice',
      text: 'What is the primary purpose of metadata in digital libraries?',
      options: [
        'To increase file size',
        'To describe digital objects and facilitate discovery',
        'To encrypt sensitive information',
        'To compress digital files'
      ],
      correctAnswer: 1
    },
    {
      id: 4,
      type: 'short_answer',
      text: 'Explain the concept of interoperability in digital libraries and why it is important.',
      wordLimit: 200
    },
    {
      id: 5,
      type: 'multiple_choice',
      text: 'Which of the following is NOT typically a component of digital preservation strategy?',
      options: [
        'Format migration',
        'Backup creation',
        'Restricting user access',
        'Checksum verification'
      ],
      correctAnswer: 2
    },
    {
      id: 6,
      type: 'multiple_choice',
      text: 'Dublin Core is an example of:',
      options: [
        'A programming language for digital libraries',
        'A digital preservation technique',
        'A metadata standard',
        'A database management system'
      ],
      correctAnswer: 2
    },
    {
      id: 7,
      type: 'short_answer',
      text: 'Describe at least two challenges faced when implementing digital libraries in developing countries.',
      wordLimit: 200
    },
    {
      id: 8,
      type: 'multiple_choice',
      text: 'Which of the following file formats is most suitable for long-term preservation of text documents?',
      options: [
        '.doc',
        '.pdf/a',
        '.txt',
        '.rtf'
      ],
      correctAnswer: 1
    },
    {
      id: 9,
      type: 'multiple_choice',
      text: 'What does OAI-PMH stand for in the context of digital libraries?',
      options: [
        'Open Access Initiative - Public Management Handle',
        'Open Archives Initiative - Protocol for Metadata Harvesting',
        'Online Academic Interface - Program for Material Handling',
        'Open API - Preservation Management Handler'
      ],
      correctAnswer: 1
    },
    {
      id: 10,
      type: 'multiple_choice',
      text: 'Which of these is an example of a distributed digital library architecture?',
      options: [
        'Single server with multiple workstations',
        'Centralized database with backup system',
        'Federated search across multiple repositories',
        'Cloud storage system for a single institution'
      ],
      correctAnswer: 2
    }
  ]
};

const ExamPage: React.FC = () => {
  const [, params] = useRoute<{ courseId: string, examId: string }>('/online-learning/courses/:courseId/exams/:examId');
  const courseId = parseInt(params?.courseId || '1');
  const examId = parseInt(params?.examId || '101');
  
  // Find the current course
  const course = courses.find(c => c.id === courseId) || courses[0];
  
  const [currentStep, setCurrentStep] = useState<'intro' | 'exam' | 'review' | 'results'>('intro');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<(number | string | null)[]>(Array(examData.questions.length).fill(null));
  const [timeRemaining, setTimeRemaining] = useState(examData.duration * 60); // in seconds
  const [examComplete, setExamComplete] = useState(false);
  const [examScore, setExamScore] = useState<number | null>(null);
  
  // Mock function to handle starting the exam
  const handleStartExam = () => {
    setCurrentStep('exam');
    // In a real app, this would start a timer countdown
  };
  
  // Mock function to handle answering a question
  const handleAnswerQuestion = (answer: number | string) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestionIndex] = answer;
    setAnswers(newAnswers);
  };
  
  // Navigate to the next question
  const goToNextQuestion = () => {
    if (currentQuestionIndex < examData.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      setCurrentStep('review');
    }
  };
  
  // Navigate to the previous question
  const goToPreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };
  
  // Mock function to handle submitting the exam
  const handleSubmitExam = () => {
    setExamComplete(true);
    setCurrentStep('results');
    
    // Calculate score (for multiple choice questions only in this demo)
    let correctAnswers = 0;
    let totalMultipleChoice = 0;
    
    examData.questions.forEach((question, index) => {
      if (question.type === 'multiple_choice') {
        totalMultipleChoice++;
        if (answers[index] === question.correctAnswer) {
          correctAnswers++;
        }
      }
    });
    
    const calculatedScore = Math.round((correctAnswers / totalMultipleChoice) * 100);
    setExamScore(calculatedScore);
  };
  
  // Format time in MM:SS format
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };
  
  // Get the current question
  const currentQuestion = examData.questions[currentQuestionIndex];
  
  // Calculate exam progress percentage
  const answeredCount = answers.filter(answer => answer !== null).length;
  const progressPercentage = Math.round((answeredCount / examData.questions.length) * 100);

  return (
    <div className="py-12 bg-white">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Intro Screen */}
        {currentStep === 'intro' && (
          <Card className="mb-8">
            <CardHeader className="pb-3 border-b">
              <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
                <div>
                  <div className="text-sm text-neutral-500 mb-1">
                    <Link href={`/online-learning/courses/${courseId}`}>
                      <span className="hover:text-[#0B6623] cursor-pointer">{course.code}</span>
                    </Link>
                    <span className="mx-2">/</span>
                    <span>Exam</span>
                  </div>
                  <CardTitle className="text-2xl font-georgia">{examData.title}</CardTitle>
                </div>
                <Badge className="w-fit bg-amber-100 text-amber-800 border-amber-200">
                  <Clock className="mr-1 h-4 w-4" />
                  {examData.duration} minutes
                </Badge>
              </div>
              <CardDescription className="mt-2">{examData.description}</CardDescription>
            </CardHeader>
            
            <CardContent className="pt-6">
              <div className="space-y-6">
                <div>
                  <h3 className="font-medium text-lg mb-3">Exam Instructions</h3>
                  <ul className="space-y-2">
                    {examData.instructions.map((instruction, index) => (
                      <li key={index} className="flex items-start">
                        <span className="text-[#0B6623] mr-2">•</span>
                        <span className="text-neutral-700">{instruction}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="border rounded-lg p-4 bg-neutral-50">
                    <h3 className="font-medium mb-2">Exam Details</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-neutral-600">Total Questions:</span>
                        <span className="font-medium">{examData.totalQuestions}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-600">Time Limit:</span>
                        <span className="font-medium">{examData.duration} minutes</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-600">Passing Score:</span>
                        <span className="font-medium">{examData.passingScore}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-600">Question Types:</span>
                        <span className="font-medium">Multiple Choice, Short Answer</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border rounded-lg p-4 bg-neutral-50">
                    <h3 className="font-medium mb-2">Important Notes</h3>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start">
                        <span className="text-red-500 mr-2">•</span>
                        <span className="text-neutral-700">Do not refresh or navigate away from this page during the exam.</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-red-500 mr-2">•</span>
                        <span className="text-neutral-700">Once started, the timer cannot be paused.</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-red-500 mr-2">•</span>
                        <span className="text-neutral-700">Ensure you have a stable internet connection.</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-red-500 mr-2">•</span>
                        <span className="text-neutral-700">You can only submit the exam once.</span>
                      </li>
                    </ul>
                  </div>
                </div>
                
                <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 flex items-start">
                  <AlertCircle className="h-5 w-5 text-blue-500 mr-2 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-medium text-blue-800">Ready to Begin?</h3>
                    <p className="text-blue-700 text-sm mt-1">
                      Once you start the exam, the timer will begin counting down. Make sure you are ready to complete
                      the entire exam before proceeding.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
            
            <CardFooter className="border-t bg-neutral-50 flex justify-between">
              <Link href={`/online-learning/courses/${courseId}`}>
                <Button variant="outline">
                  <ChevronLeft className="mr-1 h-4 w-4" />
                  Return to Course
                </Button>
              </Link>
              <Button className="bg-[#0B6623] hover:bg-[#094d1c]" onClick={handleStartExam}>
                Start Exam
              </Button>
            </CardFooter>
          </Card>
        )}
        
        {/* Exam Screen */}
        {currentStep === 'exam' && (
          <>
            <div className="sticky top-[72px] z-10 bg-white pb-4 border-b mb-6">
              <div className="flex justify-between items-center mb-3">
                <div>
                  <h1 className="text-xl font-semibold font-georgia">{examData.title}</h1>
                  <p className="text-sm text-neutral-500">{course.code}</p>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant="outline" className="bg-white text-neutral-600">
                    Question {currentQuestionIndex + 1} of {examData.questions.length}
                  </Badge>
                  <Badge className="bg-red-100 text-red-800 border-red-200">
                    <Clock className="mr-1 h-4 w-4" />
                    {formatTime(timeRemaining)}
                  </Badge>
                </div>
              </div>
              
              <div className="w-full">
                <Progress value={progressPercentage} className="h-2" />
                <div className="flex justify-between mt-1 text-xs text-neutral-500">
                  <span>{answeredCount} answered</span>
                  <span>{examData.questions.length - answeredCount} remaining</span>
                </div>
              </div>
            </div>
            
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant={currentQuestion.type === 'multiple_choice' ? 'blue' : 'green'} className="capitalize">
                    {currentQuestion.type.replace('_', ' ')}
                  </Badge>
                  {currentQuestion.type === 'short_answer' && (
                    <Badge variant="outline">
                      Word limit: {currentQuestion.wordLimit}
                    </Badge>
                  )}
                </div>
                <CardTitle className="text-lg font-georgia">
                  {currentQuestionIndex + 1}. {currentQuestion.text}
                </CardTitle>
              </CardHeader>
              
              <CardContent>
                {currentQuestion.type === 'multiple_choice' && (
                  <RadioGroup 
                    value={answers[currentQuestionIndex] !== null ? answers[currentQuestionIndex]?.toString() : undefined} 
                    onValueChange={(value) => handleAnswerQuestion(parseInt(value))}
                    className="space-y-3"
                  >
                    {currentQuestion.options?.map((option, index) => (
                      <div key={index} className="flex items-center space-x-2 border rounded-md p-3 hover:bg-neutral-50">
                        <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                        <Label 
                          htmlFor={`option-${index}`} 
                          className="flex-grow cursor-pointer"
                        >
                          {option}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                )}
                
                {currentQuestion.type === 'short_answer' && (
                  <div>
                    <Textarea 
                      id="answer" 
                      value={answers[currentQuestionIndex] as string || ''} 
                      onChange={(e) => handleAnswerQuestion(e.target.value)}
                      placeholder="Type your answer here..."
                      className="min-h-[200px]"
                    />
                    <div className="mt-2 text-sm text-neutral-500 flex justify-between">
                      <div>
                        <HelpCircle className="h-4 w-4 inline mr-1" />
                        Suggested word limit: {currentQuestion.wordLimit}
                      </div>
                      {(answers[currentQuestionIndex] as string)?.length > 0 && (
                        <div>
                          {(answers[currentQuestionIndex] as string).split(/\s+/).filter(Boolean).length} words
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
              
              <CardFooter className="border-t bg-neutral-50 flex justify-between">
                <Button 
                  variant="outline" 
                  onClick={goToPreviousQuestion}
                  disabled={currentQuestionIndex === 0}
                >
                  <ChevronLeft className="mr-1 h-4 w-4" />
                  Previous
                </Button>
                
                {currentQuestionIndex < examData.questions.length - 1 ? (
                  <Button 
                    variant="outline" 
                    className="text-[#0B6623]" 
                    onClick={goToNextQuestion}
                  >
                    Next
                    <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                ) : (
                  <Button 
                    className="bg-[#0B6623] hover:bg-[#094d1c]" 
                    onClick={() => setCurrentStep('review')}
                  >
                    Review Answers
                  </Button>
                )}
              </CardFooter>
            </Card>
          </>
        )}
        
        {/* Review Screen */}
        {currentStep === 'review' && (
          <Card>
            <CardHeader className="pb-3 border-b">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <CardTitle>Review Your Answers</CardTitle>
                <Badge className="w-fit bg-red-100 text-red-800 border-red-200">
                  <Clock className="mr-1 h-4 w-4" />
                  {formatTime(timeRemaining)}
                </Badge>
              </div>
              <CardDescription>
                Review all your answers before submitting. You can go back to any question to change your answer.
              </CardDescription>
            </CardHeader>
            
            <CardContent className="pt-6">
              <div className="space-y-4">
                {examData.questions.map((question, index) => (
                  <div key={index} className="border rounded-lg p-4 hover:bg-neutral-50">
                    <div className="flex justify-between">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="font-medium">
                          {index + 1}
                        </Badge>
                        <p className="font-medium">{question.text.length > 100 ? question.text.substring(0, 100) + '...' : question.text}</p>
                      </div>
                      <div>
                        {answers[index] !== null ? (
                          <Badge variant="green" className="bg-green-100 text-green-800 border-0">
                            <CheckCircle className="mr-1 h-3 w-3" />
                            Answered
                          </Badge>
                        ) : (
                          <Badge variant="destructive" className="bg-red-100 text-red-800 border-0">
                            <XCircle className="mr-1 h-3 w-3" />
                            Not Answered
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <div className="mt-2">
                      {question.type === 'multiple_choice' && answers[index] !== null && (
                        <div className="text-sm text-neutral-600 mt-1">
                          Selected: {question.options?.[answers[index] as number]}
                        </div>
                      )}
                      
                      {question.type === 'short_answer' && answers[index] !== null && (
                        <div className="text-sm text-neutral-600 mt-1">
                          <span className="font-medium">Your answer:</span> {(answers[index] as string).length > 50 ? (answers[index] as string).substring(0, 50) + '...' : answers[index]}
                        </div>
                      )}
                      
                      <Button 
                        variant="link" 
                        className="p-0 h-auto text-[#0B6623] text-sm mt-2"
                        onClick={() => {
                          setCurrentQuestionIndex(index);
                          setCurrentStep('exam');
                        }}
                      >
                        Edit Answer
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-8 bg-amber-50 border border-amber-100 rounded-lg p-4">
                <div className="flex items-start">
                  <AlertCircle className="h-5 w-5 text-amber-500 mr-2 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-medium text-amber-800">Ready to Submit?</h3>
                    <p className="text-amber-700 text-sm mt-1">
                      You have answered {answeredCount} of {examData.questions.length} questions.
                      {answeredCount < examData.questions.length && (
                        <span className="font-medium"> Please ensure you've answered all questions before submitting.</span>
                      )}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
            
            <CardFooter className="border-t bg-neutral-50 flex justify-between">
              <Button 
                variant="outline" 
                onClick={() => {
                  setCurrentStep('exam');
                }}
              >
                <ChevronLeft className="mr-1 h-4 w-4" />
                Return to Questions
              </Button>
              
              <Button 
                className="bg-[#0B6623] hover:bg-[#094d1c]" 
                onClick={handleSubmitExam}
                disabled={answeredCount < examData.questions.length}
              >
                Submit Exam
              </Button>
            </CardFooter>
          </Card>
        )}
        
        {/* Results Screen */}
        {currentStep === 'results' && (
          <Card>
            <CardHeader className="pb-3 border-b">
              <CardTitle>Exam Results</CardTitle>
              <CardDescription>
                Thank you for completing {examData.title}
              </CardDescription>
            </CardHeader>
            
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center mb-8">
                <div 
                  className={`text-4xl font-bold ${
                    examScore && examScore >= examData.passingScore 
                      ? 'text-green-600' 
                      : 'text-red-600'
                  }`}
                >
                  {examScore}%
                </div>
                <p className="mt-2 text-neutral-600">
                  {examScore && examScore >= examData.passingScore 
                    ? 'Congratulations! You passed the exam.' 
                    : 'Unfortunately, you did not pass the exam.'}
                </p>
                <div className="w-full max-w-xs mt-4">
                  <Progress 
                    value={examScore || 0} 
                    className={`h-3 ${
                      examScore && examScore >= examData.passingScore 
                        ? 'bg-green-100' 
                        : 'bg-red-100'
                    }`}
                  />
                  <div className="flex justify-between mt-1 text-xs text-neutral-500">
                    <span>0%</span>
                    <span className="text-neutral-700 font-medium">{examData.passingScore}% needed to pass</span>
                    <span>100%</span>
                  </div>
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <div>
                <h3 className="font-medium text-lg mb-4">Question Summary</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {examData.questions.map((question, index) => {
                    // Only show pass/fail for multiple choice questions
                    const isCorrect = question.type === 'multiple_choice' && 
                      question.correctAnswer === answers[index];
                    
                    return (
                      <div key={index} className="border rounded-lg p-4 bg-neutral-50">
                        <div className="flex justify-between">
                          <Badge variant="outline" className="mb-2 bg-white">
                            Question {index + 1}
                          </Badge>
                          {question.type === 'multiple_choice' && (
                            <Badge 
                              variant={isCorrect ? "green" : "destructive"}
                              className={`${
                                isCorrect 
                                  ? 'bg-green-100 text-green-800 border-0' 
                                  : 'bg-red-100 text-red-800 border-0'
                              }`}
                            >
                              {isCorrect ? (
                                <CheckCircle className="mr-1 h-3 w-3" />
                              ) : (
                                <XCircle className="mr-1 h-3 w-3" />
                              )}
                              {isCorrect ? 'Correct' : 'Incorrect'}
                            </Badge>
                          )}
                        </div>
                        
                        <p className="text-sm font-medium text-neutral-700 mb-2">
                          {question.text.length > 100 ? question.text.substring(0, 100) + '...' : question.text}
                        </p>
                        
                        {question.type === 'multiple_choice' && (
                          <div className="text-sm">
                            <div className="text-neutral-600">
                              <span className="font-medium">Your answer:</span> {question.options?.[answers[index] as number]}
                            </div>
                            {!isCorrect && (
                              <div className="text-green-700 mt-1">
                                <span className="font-medium">Correct answer:</span> {question.options?.[question.correctAnswer]}
                              </div>
                            )}
                          </div>
                        )}
                        
                        {question.type === 'short_answer' && (
                          <div className="text-sm text-neutral-600">
                            <span className="font-medium">Your answer:</span> {(answers[index] as string).length > 50 ? (answers[index] as string).substring(0, 50) + '...' : answers[index]}
                            <div className="mt-1 italic">
                              Short answer questions will be graded manually.
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
              
              {examScore && examScore < examData.passingScore && (
                <div className="mt-8 bg-blue-50 border border-blue-100 rounded-lg p-4">
                  <div className="flex items-start">
                    <HelpCircle className="h-5 w-5 text-blue-500 mr-2 flex-shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-medium text-blue-800">Review Suggestions</h3>
                      <p className="text-blue-700 text-sm mt-1">
                        Based on your performance, we recommend reviewing the following topics:
                      </p>
                      <ul className="mt-2 space-y-1 text-blue-700 text-sm">
                        <li className="flex items-start">
                          <span className="text-blue-500 mr-2">•</span>
                          <span>Digital library architecture components</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-blue-500 mr-2">•</span>
                          <span>Metadata standards and applications</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-blue-500 mr-2">•</span>
                          <span>Digital preservation techniques</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
            
            <CardFooter className="border-t bg-neutral-50 flex justify-center md:justify-between">
              <Link href={`/online-learning/courses/${courseId}`}>
                <Button className="bg-[#0B6623] hover:bg-[#094d1c]">
                  Return to Course
                </Button>
              </Link>
              
              <div className="hidden md:flex space-x-3">
                <Button 
                  variant="outline" 
                  onClick={() => window.print()}
                >
                  Print Results
                </Button>
                
                <Button 
                  className="bg-yellow-500 hover:bg-yellow-400 text-black"
                >
                  Contact Instructor
                </Button>
              </div>
            </CardFooter>
          </Card>
        )}
      </div>
    </div>
  );
};

export default ExamPage;