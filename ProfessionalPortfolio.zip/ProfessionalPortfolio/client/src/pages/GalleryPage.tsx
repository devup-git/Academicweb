import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { X, Calendar, Info, Maximize2 } from 'lucide-react';

// Mock gallery data - will be replaced with real data
const galleryImages = [
  {
    id: 1,
    title: "Digital Preservation Workshop",
    description: "Workshop on digital preservation techniques for library science professionals",
    imageUrl: "/path/to/image1.jpg",
    thumbnailUrl: "/path/to/thumb1.jpg",
    category: "events",
    uploadedAt: new Date('2023-11-10')
  },
  {
    id: 2,
    title: "Library Science Conference 2023",
    description: "Presenting research at the annual Library Science Conference in Lagos",
    imageUrl: "/path/to/image2.jpg",
    thumbnailUrl: "/path/to/thumb2.jpg",
    category: "conferences",
    uploadedAt: new Date('2023-09-15')
  },
  {
    id: 3,
    title: "Students Research Showcase",
    description: "BSU Library Science students showcasing their research projects",
    imageUrl: "/path/to/image3.jpg",
    thumbnailUrl: "/path/to/thumb3.jpg",
    category: "teaching",
    uploadedAt: new Date('2023-07-22')
  },
  {
    id: 4,
    title: "Indigenous Knowledge Documentation Project",
    description: "Field work documenting indigenous knowledge in Benue State",
    imageUrl: "/path/to/image4.jpg",
    thumbnailUrl: "/path/to/thumb4.jpg",
    category: "research",
    uploadedAt: new Date('2023-06-05')
  },
  {
    id: 5,
    title: "Guest Lecture at University of Ibadan",
    description: "Delivering a guest lecture on digital libraries and information access",
    imageUrl: "/path/to/image5.jpg",
    thumbnailUrl: "/path/to/thumb5.jpg",
    category: "speaking",
    uploadedAt: new Date('2023-05-18')
  },
  {
    id: 6,
    title: "BSU Library Science Department",
    description: "The Library Science Department building at Benue State University",
    imageUrl: "/path/to/image6.jpg",
    thumbnailUrl: "/path/to/thumb6.jpg",
    category: "campus",
    uploadedAt: new Date('2023-04-12')
  },
  {
    id: 7,
    title: "National Library Association Awards",
    description: "Receiving recognition at the National Library Association Awards",
    imageUrl: "/path/to/image7.jpg",
    thumbnailUrl: "/path/to/thumb7.jpg",
    category: "awards",
    uploadedAt: new Date('2023-03-25')
  },
  {
    id: 8,
    title: "Digital Cataloguing Workshop",
    description: "Hands-on workshop on digital cataloguing techniques",
    imageUrl: "/path/to/image8.jpg",
    thumbnailUrl: "/path/to/thumb8.jpg",
    category: "teaching",
    uploadedAt: new Date('2023-02-14')
  },
  {
    id: 9,
    title: "Academic Libraries Conference",
    description: "Panel discussion on the future of academic libraries in Nigeria",
    imageUrl: "/path/to/image9.jpg",
    thumbnailUrl: "/path/to/thumb9.jpg",
    category: "conferences",
    uploadedAt: new Date('2023-01-20')
  },
];

// Extract unique categories
const categorySet = new Set<string>();
galleryImages.forEach(img => {
  if (img.category) categorySet.add(img.category);
});
const categories = ["all", ...Array.from(categorySet)] as string[];

const GalleryPage: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState("all");
  const [selectedImage, setSelectedImage] = useState<null | number>(null);
  
  const filteredImages = activeCategory === "all" 
    ? galleryImages 
    : galleryImages.filter(img => img.category === activeCategory);
    
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric', 
      month: 'long', 
      day: 'numeric'
    }).format(date);
  };
  
  const openImageModal = (id: number) => {
    setSelectedImage(id);
  };
  
  const closeImageModal = () => {
    setSelectedImage(null);
  };
  
  const currentImage = selectedImage !== null 
    ? galleryImages.find(img => img.id === selectedImage) 
    : null;
    
  const getCategoryLabel = (category: string) => {
    // Capitalize first letter and format
    return category.charAt(0).toUpperCase() + category.slice(1);
  };

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between">
          <div>
            <h1 className="text-3xl font-bold font-georgia text-neutral-900">Gallery</h1>
            <p className="mt-4 text-lg text-neutral-600 max-w-3xl">
              A collection of images from academic events, research projects, teaching activities, and professional engagements.
            </p>
          </div>
          <Button className="mt-4 md:mt-0 bg-yellow-500 hover:bg-yellow-400 text-black">
            Request Image Use Permission
          </Button>
        </div>
        
        {/* Category Tabs */}
        <Tabs 
          value={activeCategory} 
          onValueChange={setActiveCategory}
          className="mt-8"
        >
          <TabsList className="w-full flex-wrap sm:w-auto">
            {categories.map(category => (
              <TabsTrigger 
                key={category} 
                value={category}
                className="capitalize"
              >
                {getCategoryLabel(category)}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
        
        {/* Gallery Grid */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {filteredImages.map(image => (
            <Card 
              key={image.id} 
              className="overflow-hidden cursor-pointer transition-transform hover:shadow-md transform hover:-translate-y-1"
              onClick={() => openImageModal(image.id)}
            >
              <div className="relative aspect-square bg-neutral-100 overflow-hidden group">
                {/* Here we use a placeholder div, in real app an actual image would be used */}
                <div className="w-full h-full flex items-center justify-center text-neutral-400">
                  [Gallery Image]
                </div>
                
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                  <h3 className="text-white font-medium text-lg">{image.title}</h3>
                  <p className="text-white/80 text-sm mt-1 line-clamp-2">{image.description}</p>
                </div>
                
                <Button 
                  size="icon"
                  variant="ghost" 
                  className="absolute top-2 right-2 bg-black/30 text-white hover:bg-black/50 invisible group-hover:visible"
                >
                  <Maximize2 className="h-4 w-4" />
                </Button>
              </div>
              
              <CardContent className="p-3">
                <div className="flex items-center justify-between text-sm text-neutral-500">
                  <div className="flex items-center">
                    <Calendar className="h-3 w-3 mr-1" />
                    <span>{formatDate(image.uploadedAt)}</span>
                  </div>
                  <div className="capitalize bg-neutral-100 px-2 py-0.5 rounded-full text-xs">
                    {image.category}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {/* Empty state */}
        {filteredImages.length === 0 && (
          <div className="py-16 text-center">
            <p className="text-neutral-500">No images found in this category.</p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => setActiveCategory("all")}
            >
              View all images
            </Button>
          </div>
        )}
        
        {/* Image Modal */}
        <Dialog open={selectedImage !== null} onOpenChange={(open) => !open && closeImageModal()}>
          <DialogContent className="sm:max-w-4xl p-0 bg-neutral-900 border-neutral-800">
            <Button 
              variant="ghost" 
              size="icon" 
              className="absolute right-2 top-2 z-10 text-white hover:bg-white/20 rounded-full"
              onClick={closeImageModal}
            >
              <X className="h-5 w-5" />
            </Button>
            
            {currentImage && (
              <>
                <div className="aspect-video bg-neutral-800 w-full flex items-center justify-center">
                  {/* Placeholder for image */}
                  <div className="text-neutral-400 text-center">
                    [Full-size Gallery Image]
                  </div>
                </div>
                
                <div className="p-6 bg-neutral-800">
                  <DialogTitle className="text-white">{currentImage.title}</DialogTitle>
                  <DialogDescription className="text-neutral-300 mt-2">
                    {currentImage.description}
                  </DialogDescription>
                  
                  <div className="mt-4 flex justify-between items-center text-neutral-400 text-sm">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      <span>{formatDate(currentImage.uploadedAt)}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Info className="h-4 w-4" />
                      <span className="capitalize">{currentImage.category}</span>
                    </div>
                  </div>
                </div>
              </>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </section>
  );
};

export default GalleryPage;