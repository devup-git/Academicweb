import React from 'react';
import { Link } from 'wouter';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { featuredItems } from '@/lib/data';

const HomePage: React.FC = () => {
  return (
    <main>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-[#0B6623] to-[#094d1c] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20 lg:py-24">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-8 items-center">
            <div className="md:col-span-3 space-y-6">
              <div>
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-georgia font-bold leading-tight">
                  Dr. Doosuur Dianne Ashaver, Ph.D.
                </h1>
                <p className="mt-2 text-xl md:text-2xl text-green-100">
                  Doctor of Library and Information Science
                </p>
                <p className="mt-1 text-lg md:text-xl text-green-100">
                  Benue State University, Makurdi
                </p>
              </div>
              
              <p className="text-lg md:text-xl leading-relaxed">
                Welcome! I'm a lecturer at Benue State University, Makurdi, specializing in Library and Information Science. Explore my work on information management, digital libraries, and education.
              </p>
              
              <div className="pt-4 flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
                <Button
                  asChild
                  variant="secondary"
                  className="px-6 py-3 text-[#0B6623] bg-white hover:bg-neutral-100"
                >
                  <Link href="/research">
                    Research Areas
                  </Link>
                </Button>
                <Button
                  asChild
                  variant="default"
                  className="px-6 py-3 bg-yellow-500 text-black border-yellow-500 hover:bg-yellow-400"
                >
                  <Link href="/contact">
                    Contact Me
                  </Link>
                </Button>
              </div>
            </div>
            
            <div className="md:col-span-2">
              <div className="rounded-lg bg-white p-2 shadow-xl">
                <img 
                  className="w-full h-auto rounded-md" 
                  src="/images/dr_ashaver_portrait.jpg" 
                  alt="Dr. Doosuur Dianne Ashaver, Professor of Library and Information Science"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Content Section */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-2xl md:text-3xl font-georgia font-bold text-neutral-900">Featured Work</h2>
            <p className="mt-3 max-w-2xl mx-auto text-lg text-neutral-600">
              Recent research contributions and academic activities
            </p>
          </div>
          
          <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredItems.map(item => (
              <Card 
                key={item.id} 
                className="bg-neutral-50 hover:shadow-lg transition-shadow duration-300 flex flex-col overflow-hidden"
              >
                <CardContent className="p-6 flex-grow">
                  <div className="inline-block p-3 rounded-full bg-green-100 text-[#0B6623] mb-4">
                    <span className="material-icons">{item.icon}</span>
                  </div>
                  <h3 className="text-xl font-semibold text-neutral-900 font-georgia">{item.title}</h3>
                  <p className="mt-2 text-neutral-600">{item.description}</p>
                </CardContent>
                <CardFooter className="bg-neutral-100 p-4">
                  <Link 
                    href={item.linkUrl} 
                    className="text-[#0B6623] hover:text-[#094d1c] font-medium flex items-center"
                  >
                    {item.linkText}
                    <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
};

export default HomePage;
