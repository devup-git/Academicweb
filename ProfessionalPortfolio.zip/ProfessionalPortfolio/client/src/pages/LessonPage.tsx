import React, { useState } from 'react';
import { useRoute, Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import {
  ChevronLeft,
  ChevronRight,
  PlayCircle,
  FileDown,
  FileText,
  MessageSquare,
  HelpCircle,
  Video,
  CheckCircle,
  Clock,
  Calendar,
  BookOpen,
  PresentationIcon
} from 'lucide-react';
import { courses } from '@/lib/data';

// Mock lesson data (would be fetched from API in real app)
const lessonDetails = {
  id: 2,
  courseId: 1,
  title: 'Digital Library Architecture',
  description: 'This lesson explores the technical architecture and infrastructure components of digital library systems, including storage, retrieval mechanisms, and system integration.',
  videoUrl: '/path/to/video',
  recordedAt: new Date('2023-11-17'),
  duration: 75, // minutes
  materials: [
    {
      id: 1,
      title: 'Lecture Slides: Digital Library Architecture',
      description: 'Comprehensive slide deck covering all architecture components',
      type: 'presentation',
      fileSize: '4.8MB',
      downloadUrl: '/path/to/slides.pptx'
    },
    {
      id: 2,
      title: 'Architecture Diagrams',
      description: 'Visual representations of digital library system components',
      type: 'document',
      fileSize: '2.2MB',
      downloadUrl: '/path/to/diagrams.pdf'
    },
    {
      id: 3,
      title: 'Case Study: National Digital Library of India',
      description: 'In-depth analysis of NDLI architecture and implementation',
      type: 'document',
      fileSize: '3.6MB',
      downloadUrl: '/path/to/case-study.pdf'
    }
  ],
  // Transcription snippets (in a real app, this would be complete)
  transcription: [
    { time: '00:00', text: 'Welcome to today\'s lecture on Digital Library Architecture.' },
    { time: '00:18', text: 'We\'ll be exploring the key components that make up a robust digital library system.' },
    { time: '01:45', text: 'Let\'s start by looking at the three-tiered architecture commonly used in digital libraries.' },
    { time: '05:32', text: 'The data layer is responsible for the actual storage of digital objects and their metadata.' },
    { time: '10:15', text: 'Moving to the application layer, this is where the core functionality resides...' },
    { time: '18:20', text: 'The presentation layer handles user interactions and provides the interface...' },
    { time: '25:48', text: 'Let\'s examine some real-world implementations of these architectural patterns...' },
    { time: '40:12', text: 'Scalability is a critical consideration for any digital library architecture...' },
    { time: '52:30', text: 'To conclude, the architecture you choose should align with your specific needs...' },
    { time: '01:10:45', text: 'In our next session, we\'ll look at metadata standards in more detail. Thank you.' }
  ],
  // Discussion questions to prompt student engagement
  discussionQuestions: [
    'How do the three architectural tiers (data, application, presentation) interact with each other?',
    'What are the advantages and disadvantages of a distributed digital library architecture?',
    'How might the architecture of a digital library differ based on its content type (e.g., text vs. multimedia)?',
    'What security considerations should be addressed in digital library architecture?',
    'How can digital library architecture facilitate interoperability with other systems?'
  ]
};

// Mock navigation data
const lessonNavigation = {
  prev: { id: 1, title: 'Introduction to Digital Libraries' },
  next: { id: 3, title: 'Metadata Standards' }
};

const LessonPage: React.FC = () => {
  const [, params] = useRoute<{ courseId: string, lessonId: string }>('/online-learning/courses/:courseId/lessons/:lessonId');
  const courseId = parseInt(params?.courseId || '1');
  const lessonId = parseInt(params?.lessonId || '1');
  
  const [activeTab, setActiveTab] = useState('video');
  const [completedWatching, setCompletedWatching] = useState(false);
  
  // Find the current course
  const course = courses.find(c => c.id === courseId) || courses[0];
  
  // Format date in a readable form
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric', 
      month: 'long', 
      day: 'numeric'
    }).format(date);
  };
  
  // Format duration as hours and minutes
  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    
    if (hours > 0) {
      return `${hours}h ${remainingMinutes}m`;
    } else {
      return `${remainingMinutes} minutes`;
    }
  };
  
  // Mock function to handle watching video completion
  const handleWatchComplete = () => {
    setCompletedWatching(true);
  };
  
  // Get icon for material type
  const getMaterialIcon = (type: string) => {
    switch (type) {
      case 'presentation':
        return <PresentationIcon className="h-4 w-4 text-amber-500" />;
      case 'document':
        return <FileText className="h-4 w-4 text-blue-500" />;
      default:
        return <BookOpen className="h-4 w-4 text-green-500" />;
    }
  };

  return (
    <div className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header with navigation */}
        <div className="mb-8">
          <div className="flex items-center text-sm text-neutral-500 mb-2">
            <Link href={`/online-learning/courses/${courseId}`}>
              <span className="hover:text-[#0B6623] cursor-pointer">{course.code}</span>
            </Link>
            <span className="mx-2">/</span>
            <span>Lesson {lessonId}</span>
          </div>
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <h1 className="text-2xl sm:text-3xl font-bold font-georgia text-neutral-900">{lessonDetails.title}</h1>
            
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline" className="bg-white">
                <Video className="h-3 w-3 mr-1" />
                Lecture
              </Badge>
              <Badge variant="outline" className="bg-white">
                <Clock className="h-3 w-3 mr-1" />
                {formatDuration(lessonDetails.duration)}
              </Badge>
              <Badge variant="outline" className="bg-white">
                <Calendar className="h-3 w-3 mr-1" />
                {formatDate(lessonDetails.recordedAt)}
              </Badge>
            </div>
          </div>
          
          <p className="mt-2 text-neutral-600">{lessonDetails.description}</p>
        </div>
        
        {/* Main Content */}
        <div className="grid grid-cols-12 gap-6">
          <div className="col-span-12 lg:col-span-8">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="w-full grid grid-cols-3">
                <TabsTrigger value="video">Video Lecture</TabsTrigger>
                <TabsTrigger value="materials">Materials</TabsTrigger>
                <TabsTrigger value="discussion">Discussion</TabsTrigger>
              </TabsList>
              
              {/* Video Tab */}
              <TabsContent value="video" className="mt-6">
                <Card>
                  <CardContent className="p-0">
                    {/* Video player container - in a real app, this would be a video component */}
                    <div className="aspect-video bg-neutral-900 flex items-center justify-center">
                      <div className="text-white text-center">
                        <div className="mb-4">[Video Player: {lessonDetails.title}]</div>
                        <Button 
                          variant="outline" 
                          className="border-white text-white hover:bg-white/20"
                          onClick={handleWatchComplete}
                        >
                          <PlayCircle className="mr-2 h-5 w-5" />
                          Simulate Watching Video
                        </Button>
                      </div>
                    </div>
                    
                    <div className="p-6">
                      <div className="flex justify-between items-center mb-4">
                        <h3 className="text-lg font-semibold">Video Lecture</h3>
                        {completedWatching && (
                          <Badge variant="green" className="flex items-center">
                            <CheckCircle className="mr-1 h-3 w-3" />
                            Completed
                          </Badge>
                        )}
                      </div>
                      
                      <p className="text-neutral-600 mb-6">{lessonDetails.description}</p>
                      
                      <div className="bg-neutral-50 rounded-lg p-4 border border-neutral-200">
                        <h4 className="font-medium mb-2 flex items-center">
                          <MessageSquare className="mr-2 h-4 w-4 text-neutral-500" />
                          Key Points
                        </h4>
                        <ul className="space-y-2 text-neutral-600 text-sm">
                          <li className="flex items-start">
                            <span className="text-[#0B6623] mr-2">•</span>
                            <span>Three-tiered architecture: data, application, and presentation layers</span>
                          </li>
                          <li className="flex items-start">
                            <span className="text-[#0B6623] mr-2">•</span>
                            <span>Storage considerations for different types of digital objects</span>
                          </li>
                          <li className="flex items-start">
                            <span className="text-[#0B6623] mr-2">•</span>
                            <span>Scalability approaches for growing digital collections</span>
                          </li>
                          <li className="flex items-start">
                            <span className="text-[#0B6623] mr-2">•</span>
                            <span>Real-world case studies of successful digital library implementations</span>
                          </li>
                          <li className="flex items-start">
                            <span className="text-[#0B6623] mr-2">•</span>
                            <span>Integration considerations with existing library systems</span>
                          </li>
                        </ul>
                      </div>
                      
                      <Accordion type="single" collapsible className="mt-6">
                        <AccordionItem value="transcript">
                          <AccordionTrigger>
                            <div className="flex items-center">
                              <FileText className="mr-2 h-4 w-4" />
                              Lecture Transcript
                            </div>
                          </AccordionTrigger>
                          <AccordionContent>
                            <div className="space-y-4 text-sm text-neutral-700 mt-2 max-h-80 overflow-y-auto pr-2">
                              {lessonDetails.transcription.map((item, index) => (
                                <div key={index} className="flex">
                                  <span className="text-neutral-500 w-12 flex-shrink-0">{item.time}</span>
                                  <span>{item.text}</span>
                                </div>
                              ))}
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      </Accordion>
                    </div>
                  </CardContent>
                  
                  <CardFooter className="border-t bg-neutral-50 flex flex-wrap justify-between gap-3">
                    <Button 
                      variant="outline" 
                      disabled={!lessonNavigation.prev}
                      onClick={() => {
                        if (lessonNavigation.prev) {
                          window.location.href = `/online-learning/courses/${courseId}/lessons/${lessonNavigation.prev.id}`;
                        }
                      }}
                    >
                      <ChevronLeft className="mr-2 h-4 w-4" />
                      {lessonNavigation.prev ? `Previous: ${lessonNavigation.prev.title}` : 'No Previous Lesson'}
                    </Button>
                    
                    <Button 
                      variant="outline" 
                      disabled={!lessonNavigation.next}
                      onClick={() => {
                        if (lessonNavigation.next) {
                          window.location.href = `/online-learning/courses/${courseId}/lessons/${lessonNavigation.next.id}`;
                        }
                      }}
                    >
                      {lessonNavigation.next ? `Next: ${lessonNavigation.next.title}` : 'No Next Lesson'}
                      <ChevronRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
              
              {/* Materials Tab */}
              <TabsContent value="materials" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Lesson Materials</CardTitle>
                    <CardDescription>
                      Download lecture slides and supplementary materials for this lesson
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="space-y-4">
                      {lessonDetails.materials.map((material) => (
                        <div key={material.id} className="flex p-4 border rounded-lg hover:bg-neutral-50 transition-colors">
                          <div className={`rounded-full p-1.5 mr-4 ${
                            material.type === 'presentation' ? 'bg-amber-100' : 
                            material.type === 'document' ? 'bg-blue-100' : 'bg-green-100'
                          }`}>
                            {getMaterialIcon(material.type)}
                          </div>
                          
                          <div className="flex-1">
                            <h3 className="font-medium">{material.title}</h3>
                            <p className="text-sm text-neutral-600 mt-1">{material.description}</p>
                            <div className="mt-2 text-xs text-neutral-500">
                              {material.fileSize} • {material.type}
                            </div>
                          </div>
                          
                          <div className="ml-4 flex items-center">
                            <Button size="sm" variant="outline" className="text-[#0B6623]">
                              <FileDown className="mr-1 h-4 w-4" />
                              Download
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Discussion Tab */}
              <TabsContent value="discussion" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Discussion Questions</CardTitle>
                    <CardDescription>
                      Reflect on these questions to deepen your understanding of the material
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="space-y-6">
                      {lessonDetails.discussionQuestions.map((question, index) => (
                        <div key={index} className="p-4 border rounded-lg bg-neutral-50">
                          <div className="flex items-start">
                            <HelpCircle className="h-5 w-5 text-[#0B6623] mr-3 mt-0.5 flex-shrink-0" />
                            <div>
                              <h3 className="font-medium text-neutral-900">Question {index + 1}</h3>
                              <p className="mt-1 text-neutral-700">{question}</p>
                            </div>
                          </div>
                          
                          <Separator className="my-4" />
                          
                          <div className="px-8">
                            <p className="text-sm text-neutral-500 italic mb-2">Your reflection (private to you):</p>
                            <textarea 
                              className="w-full p-3 border rounded-md h-24 text-sm focus:outline-none focus:ring-2 focus:ring-[#0B6623] focus:border-transparent" 
                              placeholder="Type your thoughts on this question here..."
                            />
                            <div className="flex justify-end mt-2">
                              <Button size="sm" className="bg-[#0B6623] hover:bg-[#094d1c]">
                                Save Reflection
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
          
          {/* Sidebar */}
          <div className="col-span-12 lg:col-span-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle>Lesson Resources</CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-6">
                {/* Materials Summary */}
                <div>
                  <h3 className="font-medium mb-3">Available Materials</h3>
                  <ul className="space-y-2 text-sm">
                    {lessonDetails.materials.map((material, index) => (
                      <li key={index} className="flex items-center">
                        {getMaterialIcon(material.type)}
                        <span className="ml-2 text-neutral-700">{material.title}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <Separator />
                
                {/* Learning Objectives */}
                <div>
                  <h3 className="font-medium mb-3">Learning Objectives</h3>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start">
                      <span className="text-[#0B6623] mr-2">•</span>
                      <span className="text-neutral-700">Understand the components of digital library architecture</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-[#0B6623] mr-2">•</span>
                      <span className="text-neutral-700">Analyze the roles of different architectural layers</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-[#0B6623] mr-2">•</span>
                      <span className="text-neutral-700">Evaluate scalability approaches for digital collections</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-[#0B6623] mr-2">•</span>
                      <span className="text-neutral-700">Apply architectural concepts to real-world case studies</span>
                    </li>
                  </ul>
                </div>
                
                <Separator />
                
                {/* Related Lessons */}
                <div>
                  <h3 className="font-medium mb-3">Related Lessons</h3>
                  <ul className="space-y-3 text-sm">
                    <li>
                      <Link href={`/online-learning/courses/${courseId}/lessons/1`}>
                        <span className="text-[#0B6623] hover:underline cursor-pointer flex items-center">
                          <ChevronRight className="h-3 w-3 mr-1" />
                          Introduction to Digital Libraries
                        </span>
                      </Link>
                    </li>
                    <li>
                      <Link href={`/online-learning/courses/${courseId}/lessons/3`}>
                        <span className="text-[#0B6623] hover:underline cursor-pointer flex items-center">
                          <ChevronRight className="h-3 w-3 mr-1" />
                          Metadata Standards
                        </span>
                      </Link>
                    </li>
                    <li>
                      <Link href={`/online-learning/courses/${courseId}/lessons/5`}>
                        <span className="text-[#0B6623] hover:underline cursor-pointer flex items-center">
                          <ChevronRight className="h-3 w-3 mr-1" />
                          Digital Preservation Strategies
                        </span>
                      </Link>
                    </li>
                  </ul>
                </div>
                
                {/* Action Buttons */}
                <div className="pt-2">
                  {!completedWatching ? (
                    <Button className="w-full bg-[#0B6623] hover:bg-[#094d1c]" onClick={handleWatchComplete}>
                      <CheckCircle className="mr-2 h-4 w-4" />
                      Mark as Completed
                    </Button>
                  ) : (
                    <Button className="w-full bg-neutral-100 text-neutral-700 hover:bg-neutral-200" disabled>
                      <CheckCircle className="mr-2 h-4 w-4" />
                      Lesson Completed
                    </Button>
                  )}
                  
                  <Link href={`/online-learning/courses/${courseId}`}>
                    <Button variant="outline" className="w-full mt-3">
                      Return to Course
                    </Button>
                  </Link>
                  
                  <Button className="w-full mt-3 bg-yellow-500 text-black hover:bg-yellow-400">
                    Contact Instructor
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LessonPage;