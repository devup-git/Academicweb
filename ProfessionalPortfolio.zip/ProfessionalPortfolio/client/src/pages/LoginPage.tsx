import React from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { LockIcon, School, User, BookOpen } from 'lucide-react';

const LoginPage: React.FC = () => {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock login - in a real app, this would authenticate with a backend
    toast({
      title: "Authentication Coming Soon",
      description: "Login functionality will be implemented in a future update.",
    });
  };
  
  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock registration
    toast({
      title: "Registration Coming Soon",
      description: "Registration functionality will be implemented in a future update.",
    });
  };

  return (
    <div className="min-h-screen py-12 bg-neutral-50">
      <div className="container grid lg:grid-cols-2 place-items-center gap-12 px-4">
        {/* Auth Form */}
        <Card className="w-full max-w-md shadow-lg border-neutral-200">
          <CardHeader className="space-y-1">
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-[#0B6623]/10 mx-auto mb-4">
              <LockIcon className="w-6 h-6 text-[#0B6623]" />
            </div>
            <CardTitle className="text-2xl font-bold text-center">Student Portal</CardTitle>
            <CardDescription className="text-center">
              Log in to access course materials and assessments
            </CardDescription>
          </CardHeader>
          
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
            
            <TabsContent value="login">
              <form onSubmit={handleLogin}>
                <CardContent className="space-y-4 pt-6">
                  <div className="space-y-2">
                    <Label htmlFor="username">BSU Student ID or Username</Label>
                    <Input id="username" placeholder="Your BSU Student ID or Username" required />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="password">Password</Label>
                      <Link href="#" className="text-sm text-[#0B6623] hover:underline">
                        Forgot password?
                      </Link>
                    </div>
                    <Input id="password" type="password" placeholder="Your password" required />
                  </div>
                </CardContent>
                
                <CardFooter className="flex flex-col">
                  <Button type="submit" className="w-full bg-[#0B6623] hover:bg-[#094d1c]">
                    Login
                  </Button>
                </CardFooter>
              </form>
            </TabsContent>
            
            <TabsContent value="register">
              <form onSubmit={handleRegister}>
                <CardContent className="space-y-4 pt-6">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Full Name</Label>
                    <Input id="fullName" placeholder="Your full name" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="studentId">BSU Student ID</Label>
                    <Input id="studentId" placeholder="Your BSU Student ID" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">BSU Email</Label>
                    <Input id="email" type="email" placeholder="your.name@student.bsu.edu.ng" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="newPassword">Password</Label>
                    <Input id="newPassword" type="password" placeholder="Create a password" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm Password</Label>
                    <Input id="confirmPassword" type="password" placeholder="Confirm your password" required />
                  </div>
                </CardContent>
                
                <CardFooter className="flex flex-col">
                  <Button type="submit" className="w-full bg-[#0B6623] hover:bg-[#094d1c]">
                    Register
                  </Button>
                  <p className="mt-2 text-xs text-center text-neutral-500">
                    By registering, you agree to the terms of service for student portal access
                  </p>
                </CardFooter>
              </form>
            </TabsContent>
          </Tabs>
        </Card>
        
        {/* Informational Section */}
        <div className="flex flex-col items-start justify-center space-y-6 max-w-md">
          <div>
            <h1 className="text-3xl font-bold font-georgia mb-4 text-neutral-900">
              Student Learning Portal
            </h1>
            <p className="text-neutral-600">
              Dr. Ashaver's online learning platform gives you access to course materials, 
              assignments, and assessments for BSU Library & Information Science students.
            </p>
          </div>
          
          <div className="grid gap-4 w-full">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-[#0B6623]/10 flex items-center justify-center flex-shrink-0">
                <BookOpen className="w-5 h-5 text-[#0B6623]" />
              </div>
              <div>
                <h3 className="font-semibold">Course Materials Access</h3>
                <p className="text-sm text-neutral-600">Access lecture slides, readings, and supplementary resources</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-[#0B6623]/10 flex items-center justify-center flex-shrink-0">
                <School className="w-5 h-5 text-[#0B6623]" />
              </div>
              <div>
                <h3 className="font-semibold">Online Assessments</h3>
                <p className="text-sm text-neutral-600">Complete exams and submit assignments through the platform</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-[#0B6623]/10 flex items-center justify-center flex-shrink-0">
                <User className="w-5 h-5 text-[#0B6623]" />
              </div>
              <div>
                <h3 className="font-semibold">Student Dashboard</h3>
                <p className="text-sm text-neutral-600">Track your progress, grades, and upcoming course activities</p>
              </div>
            </div>
          </div>
          
          <Button 
            variant="link" 
            className="text-[#0B6623] p-0 h-auto"
            onClick={() => setLocation('/online-learning')}
          >
            Return to Learning Portal
          </Button>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;