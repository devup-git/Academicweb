import React, { useState } from 'react';
import { Link } from 'wouter';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, User, Tag, ChevronRight, Search, X } from 'lucide-react';

// Mock news data - will be replaced with real data
const newsData = [
  {
    id: 1,
    title: "Workshop on Digital Cataloguing",
    summary: "A two-day workshop on modern digital cataloguing techniques for library science students and professionals.",
    content: "The Department of Library and Information Science at Benue State University will be hosting a workshop on digital cataloguing techniques. This workshop aims to equip students and professionals with practical skills for organizing digital collections using the latest metadata standards and technologies...",
    publishedAt: new Date('2023-11-15'),
    updatedAt: new Date('2023-11-15'),
    imageUrl: '/path/to/workshop-image.jpg',
    tags: ['Workshop', 'Digital Libraries', 'Cataloguing']
  },
  {
    id: 2,
    title: "New Research Grant Awarded for Indigenous Knowledge Preservation",
    summary: "Dr. Ashaver has been awarded a grant to document and digitally preserve indigenous knowledge in Benue State.",
    content: "I am pleased to announce that our research team has been awarded a significant grant to support our project on documenting and digitally preserving indigenous knowledge from various communities in Benue State...",
    publishedAt: new Date('2023-10-20'),
    updatedAt: new Date('2023-10-22'),
    imageUrl: '/path/to/research-grant-image.jpg',
    tags: ['Research', 'Indigenous Knowledge', 'Grant']
  },
  {
    id: 3,
    title: "Library and Information Science Association Conference 2023",
    summary: "Dr. Ashaver will be presenting research findings at the upcoming LISA Conference in Lagos.",
    content: "I will be presenting our latest research findings on digital preservation practices in Nigerian academic libraries at the upcoming Library and Information Science Association Conference in Lagos. The presentation will address key challenges and propose innovative solutions for enhancing digital preservation infrastructure...",
    publishedAt: new Date('2023-09-05'),
    updatedAt: new Date('2023-09-10'),
    imageUrl: '/path/to/conference-image.jpg',
    tags: ['Conference', 'Research', 'Academic Libraries']
  },
  {
    id: 4,
    title: "New Course on Information Literacy Announced for Spring 2024",
    summary: "A new course focusing on advanced information literacy skills will be offered next semester.",
    content: "I am excited to announce a new course offering for the Spring 2024 semester. LIS 325: Advanced Information Literacy will focus on developing critical evaluation skills for various information sources, with special emphasis on digital media and academic research...",
    publishedAt: new Date('2023-08-15'),
    updatedAt: new Date('2023-08-15'),
    imageUrl: '/path/to/course-image.jpg',
    tags: ['Course Announcement', 'Information Literacy', 'Teaching']
  },
];

const NewsPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  
  // Filter news based on search term
  const filteredNews = newsData.filter(item => 
    searchTerm === '' || 
    item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.summary.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Format date to display in a readable format
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric', 
      month: 'long', 
      day: 'numeric'
    }).format(date);
  };

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold font-georgia text-neutral-900">News & Updates</h1>
        <p className="mt-4 text-lg text-neutral-600">
          Stay updated with the latest news, events, and announcements from Dr. Ashaver's academic activities.
        </p>
        
        {/* Search */}
        <div className="mt-8 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-500 h-4 w-4" />
          <Input
            type="search"
            placeholder="Search news by title, content, or tag..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 w-full max-w-md"
          />
          {searchTerm && (
            <button 
              className="absolute right-3 top-1/2 transform -translate-y-1/2" 
              onClick={() => setSearchTerm('')}
              aria-label="Clear search"
            >
              <X className="h-4 w-4 text-neutral-500" />
            </button>
          )}
        </div>
        
        {/* News articles */}
        <div className="mt-8 grid gap-8">
          {filteredNews.length > 0 ? (
            filteredNews.map(news => (
              <Card key={news.id} className="overflow-hidden hover:shadow-md transition-shadow duration-300">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row gap-6">
                    {news.imageUrl && (
                      <div className="md:w-1/4 h-48 md:h-auto bg-neutral-100 rounded-md flex items-center justify-center">
                        <div className="text-neutral-400 text-center p-4">
                          [News Image]
                        </div>
                      </div>
                    )}
                    
                    <div className="md:w-3/4">
                      <div className="flex items-center text-sm text-neutral-500 mb-2">
                        <Calendar className="h-4 w-4 mr-1" />
                        <span>{formatDate(news.publishedAt)}</span>
                        {news.updatedAt > news.publishedAt && (
                          <span className="ml-2 italic">(Updated: {formatDate(news.updatedAt)})</span>
                        )}
                      </div>
                      
                      <h2 className="text-xl font-bold font-georgia text-neutral-900 mb-2">{news.title}</h2>
                      <p className="text-neutral-600 mb-4">{news.summary}</p>
                      
                      <div className="flex flex-wrap gap-2 mb-4">
                        {news.tags.map((tag, index) => (
                          <Badge key={index} variant="outline" className="cursor-pointer hover:bg-neutral-100" onClick={() => setSearchTerm(tag)}>
                            <Tag className="h-3 w-3 mr-1" />
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      
                      <Link href={`/news/${news.id}`}>
                        <Button variant="link" className="p-0 h-auto text-[#0B6623] hover:text-[#094d1c] font-medium">
                          Read more <ChevronRight className="h-4 w-4 ml-1" />
                        </Button>
                      </Link>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="text-center py-16 bg-neutral-50 rounded-lg">
              <p className="text-neutral-500">No news articles found matching your search.</p>
              {searchTerm && (
                <Button 
                  variant="outline" 
                  className="mt-4"
                  onClick={() => setSearchTerm('')}
                >
                  Clear search
                </Button>
              )}
            </div>
          )}
        </div>
        
        {/* Pagination */}
        {filteredNews.length > 0 && (
          <div className="mt-12 flex justify-center">
            <div className="inline-flex items-center space-x-2">
              <Button variant="outline" size="sm" disabled>Previous</Button>
              <Button variant="outline" size="sm" className="bg-[#0B6623] text-white hover:bg-[#094d1c]">1</Button>
              <Button variant="outline" size="sm">2</Button>
              <Button variant="outline" size="sm">3</Button>
              <Button variant="outline" size="sm">Next</Button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default NewsPage;