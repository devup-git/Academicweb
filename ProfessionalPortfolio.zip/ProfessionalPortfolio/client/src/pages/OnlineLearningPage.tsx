import React, { useState } from 'react';
import { Link } from 'wouter';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Clock, Users, Calendar, PlayCircle, BookOpen, School, LockIcon, Search } from 'lucide-react';
import { courses } from '@/lib/data';

const OnlineLearningPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  
  // Filter courses based on search term and active tab
  const filteredCourses = courses.filter(course => {
    const matchesSearch = searchTerm.trim() === '' || 
      course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.description.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesTab = activeTab === 'all' || 
      (activeTab === 'current' && course.semester.includes('2023')) ||
      (activeTab === 'upcoming' && course.semester.includes('2024'));
      
    return matchesSearch && matchesTab;
  });

  return (
    <main className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold font-georgia text-neutral-900">Online Learning Portal</h1>
          <p className="mt-4 text-lg text-neutral-600 max-w-3xl mx-auto">
            Access course materials, attend virtual classes, and participate in online assessments. 
            This platform is exclusively for BSU students enrolled in my courses.
          </p>
        </div>
        
        {/* Login Note */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-8 flex items-center gap-3">
          <LockIcon className="h-6 w-6 text-yellow-500 flex-shrink-0" />
          <div>
            <h3 className="font-medium text-yellow-800">Student Access Required</h3>
            <p className="text-yellow-700">
              Please <Link href="/login" className="underline text-yellow-800 hover:text-yellow-900">log in</Link> with your BSU student credentials to access course materials and assessments.
            </p>
          </div>
        </div>
        
        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8 items-center">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-500 h-4 w-4" />
            <Input
              type="search"
              placeholder="Search courses by title or code..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full md:w-auto">
            <TabsList>
              <TabsTrigger value="all">All Courses</TabsTrigger>
              <TabsTrigger value="current">Current</TabsTrigger>
              <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
        
        {/* Courses Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCourses.map((course) => (
            <Card key={course.id} className="overflow-hidden transition-all duration-300 hover:shadow-md hover:border-green-200">
              <CardHeader className="bg-neutral-50 border-b pb-3">
                <div className="flex justify-between items-start">
                  <Badge variant="outline" className="mb-2 bg-white">
                    {course.code}
                  </Badge>
                  <Badge variant={course.semester.includes('2023') ? 'green' : 'blue'}>
                    {course.semester}
                  </Badge>
                </div>
                <CardTitle className="text-lg font-georgia">{course.title}</CardTitle>
              </CardHeader>
              
              <CardContent className="pt-4">
                <p className="text-neutral-600 line-clamp-3 mb-4">{course.description}</p>
                
                <div className="space-y-2 text-sm text-neutral-500">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-neutral-400" />
                    <span>{course.schedule}</span>
                  </div>
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-2 text-neutral-400" />
                    <span>25 Students Enrolled</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-2 text-neutral-400" />
                    <span>12 Lessons</span>
                  </div>
                </div>
              </CardContent>
              
              <CardFooter className="flex justify-between pt-2 border-t bg-neutral-50">
                <Link href={`/online-learning/courses/${course.id}`}>
                  <Button variant="link" className="text-[#0B6623] p-0 h-auto font-medium">
                    View Course
                  </Button>
                </Link>
                <div className="flex space-x-2">
                  <Button variant="ghost" size="icon" className="h-8 w-8" title="Lecture Materials">
                    <BookOpen className="h-4 w-4 text-neutral-500" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8" title="Recorded Lectures">
                    <PlayCircle className="h-4 w-4 text-neutral-500" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8" title="Course Syllabus">
                    <School className="h-4 w-4 text-neutral-500" />
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
        
        {/* Empty State */}
        {filteredCourses.length === 0 && (
          <div className="text-center py-16">
            <School className="h-12 w-12 mx-auto text-neutral-300" />
            <h3 className="mt-4 text-lg font-medium text-neutral-600">No courses found</h3>
            <p className="mt-2 text-neutral-500">Try adjusting your search or filter criteria</p>
            {searchTerm && (
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => setSearchTerm('')}
              >
                Clear Search
              </Button>
            )}
          </div>
        )}
        
        {/* Course Access Information */}
        <div className="mt-16 bg-neutral-50 rounded-lg p-6 border border-neutral-200">
          <h2 className="text-xl font-georgia font-semibold text-neutral-900 mb-4">Course Access Information</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium text-neutral-800 mb-2">For BSU Students</h3>
              <ul className="space-y-2 text-neutral-600">
                <li className="flex items-start">
                  <span className="text-[#0B6623] mr-2">•</span>
                  <span>Login with your BSU student credentials</span>
                </li>
                <li className="flex items-start">
                  <span className="text-[#0B6623] mr-2">•</span>
                  <span>You'll automatically be enrolled in courses you're registered for</span>
                </li>
                <li className="flex items-start">
                  <span className="text-[#0B6623] mr-2">•</span>
                  <span>Access requires course-specific password provided in class</span>
                </li>
                <li className="flex items-start">
                  <span className="text-[#0B6623] mr-2">•</span>
                  <span>Contact me if you have trouble accessing your enrolled courses</span>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-neutral-800 mb-2">Features</h3>
              <ul className="space-y-2 text-neutral-600">
                <li className="flex items-start">
                  <span className="text-[#0B6623] mr-2">•</span>
                  <span>Access course materials, lecture slides, and readings</span>
                </li>
                <li className="flex items-start">
                  <span className="text-[#0B6623] mr-2">•</span>
                  <span>Join live virtual classes via Zoom integration</span>
                </li>
                <li className="flex items-start">
                  <span className="text-[#0B6623] mr-2">•</span>
                  <span>Watch recorded lectures anytime</span>
                </li>
                <li className="flex items-start">
                  <span className="text-[#0B6623] mr-2">•</span>
                  <span>Complete and submit assignments online</span>
                </li>
                <li className="flex items-start">
                  <span className="text-[#0B6623] mr-2">•</span>
                  <span>Take exams with various question formats</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="mt-6 flex justify-center">
            <Button asChild className="bg-[#0B6623] hover:bg-[#094d1c]">
              <Link href="/login">
                Login to Access Courses
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </main>
  );
};

export default OnlineLearningPage;