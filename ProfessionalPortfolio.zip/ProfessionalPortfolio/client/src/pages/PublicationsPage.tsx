import React, { useState, useMemo } from 'react';
import { FileDown, ExternalLink, BookmarkIcon, Book, BookOpen, Award, Filter, Search, X } from 'lucide-react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { publications } from '@/lib/data';
import { Publication } from '@/types';

const PublicationsPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [yearFilter, setYearFilter] = useState<string>('');
  const [tagFilters, setTagFilters] = useState<string[]>([]);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [sortBy, setSortBy] = useState<'year' | 'citations'>('year');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [visibleCount, setVisibleCount] = useState(5);
  const [activeTab, setActiveTab] = useState('all');
  
  // Extract all unique tags and years for filters
  const allTags = useMemo(() => {
    const tags = new Set<string>();
    publications.forEach(pub => pub.tags.forEach(tag => tags.add(tag)));
    return Array.from(tags).sort();
  }, []);
  
  const allYears = useMemo(() => {
    const years = new Set<number>();
    publications.forEach(pub => years.add(pub.year));
    return Array.from(years).sort((a, b) => b - a);
  }, []);
  
  const getBadgeVariant = (tag: string): "green" | "blue" | "purple" | "yellow" | "red" => {
    const tagMap: Record<string, "green" | "blue" | "purple" | "yellow" | "red"> = {
      'Digital Libraries': 'green',
      'Digital Preservation': 'green',
      'Academic Libraries': 'blue',
      'Nigeria': 'purple',
      'Information Literacy': 'yellow',
      'Higher Education': 'blue',
      'Open Access': 'green',
      'Scholarly Publishing': 'red',
      'Information Behavior': 'yellow',
      'Mobile Technology': 'purple',
      'Library Automation': 'blue',
      'Information Technology': 'purple',
      'Indigenous Knowledge': 'green',
      'Cultural Heritage': 'yellow',
      'Research Collaboration': 'blue',
      'Bibliometrics': 'red',
      'Faculty': 'blue'
    };
    
    return tagMap[tag] || 'green';
  };
  
  // Filter and sort publications
  const filteredAndSortedPublications = useMemo(() => {
    // Filter by search term, year, and tags
    let filtered = publications.filter(pub => {
      // Filter by tab
      if (activeTab === 'journal' && !pub.venue?.toLowerCase().includes('journal')) {
        return false;
      }
      if (activeTab === 'conference' && !pub.venue?.toLowerCase().includes('conference')) {
        return false;
      }
      if (activeTab === 'book' && !pub.venue?.toLowerCase().includes('book')) {
        return false;
      }
      
      // Text search
      const matchesSearch = searchTerm.trim() === '' || 
        pub.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        pub.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (pub.authors && pub.authors.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (pub.venue && pub.venue.toLowerCase().includes(searchTerm.toLowerCase()));
      
      // Year filter
      const matchesYear = yearFilter === '' || yearFilter === pub.year.toString();
      
      // Tag filters
      const matchesTags = tagFilters.length === 0 || 
        tagFilters.every(tag => pub.tags.some(t => t.toLowerCase() === tag.toLowerCase()));
      
      return matchesSearch && matchesYear && matchesTags;
    });
    
    // Sort publications
    return filtered.sort((a, b) => {
      if (sortBy === 'year') {
        return sortDirection === 'desc' ? b.year - a.year : a.year - b.year;
      } else { // sortBy === 'citations'
        const aCitations = a.citationCount || 0;
        const bCitations = b.citationCount || 0;
        return sortDirection === 'desc' ? bCitations - aCitations : aCitations - bCitations;
      }
    });
  }, [publications, searchTerm, yearFilter, tagFilters, sortBy, sortDirection, activeTab]);
  
  const visiblePublications = filteredAndSortedPublications.slice(0, visibleCount);
  const hasMore = visibleCount < filteredAndSortedPublications.length;
  
  const handleTagFilterChange = (tag: string) => {
    setTagFilters(prev => 
      prev.includes(tag) 
        ? prev.filter(t => t !== tag) 
        : [...prev, tag]
    );
  };
  
  const handleClearFilters = () => {
    setSearchTerm('');
    setYearFilter('');
    setTagFilters([]);
    setSortBy('year');
    setSortDirection('desc');
    setActiveTab('all');
  };
  
  const toggleSortDirection = () => {
    setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
  };
  
  const loadMore = () => {
    setVisibleCount(prev => prev + 5);
  };

  return (
    <section id="publications" className="py-16 bg-neutral-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold font-georgia text-neutral-900">Publications</h2>
        <p className="mt-4 text-lg text-neutral-600">
          A collection of my published research papers, articles, and book chapters.
        </p>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-8">
          <TabsList className="w-full sm:w-auto">
            <TabsTrigger value="all">All Publications</TabsTrigger>
            <TabsTrigger value="journal">Journal Articles</TabsTrigger>
            <TabsTrigger value="conference">Conference Papers</TabsTrigger>
            <TabsTrigger value="book">Book Chapters</TabsTrigger>
          </TabsList>
        </Tabs>
        
        <div className="mt-6 flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-500" />
            <Input
              id="search"
              type="search"
              placeholder="Search publications by title, author, or venue..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 w-full"
            />
            {searchTerm && (
              <button 
                className="absolute right-2 top-1/2 transform -translate-y-1/2" 
                onClick={() => setSearchTerm('')}
                aria-label="Clear search"
              >
                <X className="h-4 w-4 text-neutral-500" />
              </button>
            )}
          </div>
          
          <div className="flex gap-2">
            <Select value={yearFilter} onValueChange={setYearFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Filter by Year" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Years</SelectItem>
                {allYears.map(year => (
                  <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Button 
              variant="outline" 
              className="flex items-center gap-1"
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
            >
              <Filter className="h-4 w-4" />
              Filters
            </Button>
            
            <Select value={sortBy} onValueChange={(value) => setSortBy(value as 'year' | 'citations')}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="year">Sort by Year</SelectItem>
                <SelectItem value="citations">Sort by Citations</SelectItem>
              </SelectContent>
            </Select>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleSortDirection}
              title={`Sort ${sortDirection === 'asc' ? 'Ascending' : 'Descending'}`}
            >
              {sortDirection === 'asc' ? '↑' : '↓'}
            </Button>
          </div>
        </div>
        
        {/* Advanced filters */}
        {showAdvancedFilters && (
          <Card className="mt-4 bg-white">
            <CardContent className="pt-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-neutral-900">Filter by Tags</h3>
                {tagFilters.length > 0 && (
                  <Button variant="ghost" size="sm" onClick={() => setTagFilters([])}>
                    Clear Tags
                  </Button>
                )}
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                {allTags.map(tag => (
                  <div key={tag} className="flex items-center space-x-2">
                    <Checkbox 
                      id={`tag-${tag}`} 
                      checked={tagFilters.includes(tag)}
                      onCheckedChange={() => handleTagFilterChange(tag)}
                    />
                    <Label htmlFor={`tag-${tag}`} className="cursor-pointer">
                      {tag}
                    </Label>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter className="border-t bg-neutral-50 flex justify-between">
              <div className="text-sm text-neutral-500">
                {filteredAndSortedPublications.length} publication{filteredAndSortedPublications.length !== 1 ? 's' : ''} found
              </div>
              <Button variant="outline" size="sm" onClick={handleClearFilters}>
                Reset All Filters
              </Button>
            </CardFooter>
          </Card>
        )}
        
        {/* Results counter */}
        {(searchTerm || yearFilter || tagFilters.length > 0) && (
          <div className="mt-4 flex justify-between items-center">
            <div className="text-sm text-neutral-500">
              Showing {filteredAndSortedPublications.length} of {publications.length} publications
            </div>
            <Button variant="ghost" size="sm" onClick={handleClearFilters}>
              Clear All Filters
            </Button>
          </div>
        )}
        
        {/* Publications list */}
        <div className="mt-8 border-t border-neutral-200 pt-8 space-y-8">
          {visiblePublications.length > 0 ? (
            visiblePublications.map(publication => (
              <Card
                key={publication.id}
                className="bg-white hover:shadow-md transition-shadow duration-300"
              >
                <CardContent className="p-6">
                  <div className="flex flex-wrap justify-between items-start gap-2">
                    <h3 className="text-lg font-medium text-neutral-900 font-georgia flex-1">
                      {publication.title}
                    </h3>
                    <div className="flex items-center gap-2 whitespace-nowrap">
                      <Badge variant="outline" className="font-semibold text-neutral-700">
                        {publication.year}
                      </Badge>
                      {publication.citationCount !== undefined && (
                        <Badge variant="secondary" className="flex items-center gap-1">
                          <BookmarkIcon className="h-3 w-3" /> 
                          {publication.citationCount}
                        </Badge>
                      )}
                    </div>
                  </div>
                  
                  {publication.authors && (
                    <p className="mt-2 text-neutral-600 italic">
                      {publication.authors}
                    </p>
                  )}
                  
                  {publication.venue && (
                    <div className="mt-1 flex items-center text-neutral-500 text-sm">
                      <Book className="inline-block mr-1 h-3 w-3" /> 
                      {publication.venue}
                    </div>
                  )}
                  
                  <p className="mt-3 text-neutral-700">
                    {publication.description}
                  </p>
                  
                  <div className="mt-4 flex flex-wrap gap-2">
                    {publication.tags.map((tag, index) => (
                      <Badge 
                        key={index} 
                        variant={getBadgeVariant(tag)}
                        className="cursor-pointer"
                        onClick={() => handleTagFilterChange(tag)}
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="mt-4 flex flex-wrap gap-4">
                    {publication.pdfLink && (
                      <a 
                        href={publication.pdfLink} 
                        className="inline-flex items-center text-sm font-medium text-[#0B6623] hover:text-[#094d1c]"
                      >
                        <FileDown className="mr-1 h-4 w-4" />
                        PDF
                      </a>
                    )}
                    
                    {publication.doiLink && (
                      <a 
                        href={publication.doiLink} 
                        className="inline-flex items-center text-sm font-medium text-[#0B6623] hover:text-[#094d1c]"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <ExternalLink className="mr-1 h-4 w-4" />
                        DOI
                      </a>
                    )}
                    
                    <button
                      className="inline-flex items-center text-sm font-medium text-[#0B6623] hover:text-[#094d1c]"
                      onClick={() => {
                        navigator.clipboard.writeText(`${publication.authors}. (${publication.year}). ${publication.title}. ${publication.venue}.`);
                        alert("Citation copied to clipboard!");
                      }}
                    >
                      <BookmarkIcon className="mr-1 h-4 w-4" />
                      Copy Citation
                    </button>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="text-center py-12 text-neutral-500">
              <p>No publications found matching your search criteria.</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={handleClearFilters}
              >
                Clear all filters
              </Button>
            </div>
          )}
        </div>
        
        {hasMore && (
          <div className="mt-8 text-center">
            <Button 
              variant="outline" 
              className="text-[#0B6623] border-[#0B6623] hover:bg-green-50"
              onClick={loadMore}
            >
              Load more publications
              <span className="material-icons ml-2">expand_more</span>
            </Button>
          </div>
        )}
        
        <div className="mt-10 text-center">
          <Button className="bg-yellow-500 hover:bg-yellow-400 text-black px-6 py-2 font-medium">
            Request Publication Details or Collaboration
          </Button>
        </div>
      </div>
    </section>
  );
};

export default PublicationsPage;
