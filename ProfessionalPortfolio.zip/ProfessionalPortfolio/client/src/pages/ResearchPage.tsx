import React from 'react';
import { ChevronRight, ExternalLink } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { researchAreas } from '@/lib/data';

const ResearchPage: React.FC = () => {
  return (
    <section id="research" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold font-georgia text-neutral-900">Research</h2>
          <p className="mt-4 max-w-3xl mx-auto text-lg text-neutral-600">
            My research focuses on the evolving landscape of Library and Information Science, with particular interest in digital preservation and information management.
          </p>
        </div>
        
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {researchAreas.map(area => (
            <Card 
              key={area.id}
              className="bg-neutral-50 border border-neutral-200 hover:shadow-md transition-shadow duration-300"
            >
              <CardContent className="p-6">
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <span className="material-icons text-[#0B6623]">{area.icon}</span>
                </div>
                <h3 className="text-xl font-semibold text-neutral-900 font-georgia">{area.title}</h3>
                <p className="mt-2 text-neutral-600">{area.description}</p>
                <ul className="mt-4 space-y-2 text-neutral-700">
                  {area.topics.map((topic, index) => (
                    <li key={index} className="flex items-start">
                      <ChevronRight className="text-[#0B6623] mr-2 h-5 w-4 mt-0.5" />
                      <span>{topic}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="mt-16">
          <h3 className="text-2xl font-semibold font-georgia text-neutral-900">Current Projects</h3>
          <Card className="mt-6 bg-neutral-50 border border-neutral-200">
            <CardContent className="p-6">
              <h4 className="text-xl font-medium text-neutral-900">Preserving Indigenous Knowledge in Benue State</h4>
              <p className="mt-2 text-neutral-700">
                This project aims to document and digitally preserve indigenous knowledge systems from various communities in Benue State. Through interviews, documentation, and digital archiving, we are creating a searchable database of cultural practices, traditional agricultural methods, and oral histories.
              </p>
              <div className="mt-4 flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div className="text-neutral-600">Project timeline: 2023-2025</div>
                <a 
                  href="#" 
                  className="mt-3 sm:mt-0 inline-flex items-center text-[#0B6623] hover:text-[#094d1c] font-medium"
                >
                  View project details
                  <ExternalLink className="ml-1 h-4 w-4" />
                </a>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="mt-10 text-center">
          <button className="px-6 py-3 bg-yellow-500 hover:bg-yellow-400 text-black font-medium rounded-md inline-flex items-center">
            Contact for Research Collaboration
            <ChevronRight className="ml-1 h-4 w-4" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default ResearchPage;
