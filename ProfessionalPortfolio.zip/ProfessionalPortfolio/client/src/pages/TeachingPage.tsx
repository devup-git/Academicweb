import React from 'react';
import { Clock, CalendarIcon, FileDown } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { courses } from '@/lib/data';

const TeachingPage: React.FC = () => {
  return (
    <section id="teaching" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold font-georgia text-neutral-900">Teaching</h2>
        <p className="mt-4 text-lg text-neutral-600">
          Courses I teach at Benue State University and resources for students.
        </p>
        
        <div className="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {courses.map(course => (
            <Card 
              key={course.id}
              className="bg-neutral-50 border border-neutral-200 hover:shadow-md transition-shadow duration-300"
            >
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-neutral-900 font-georgia">
                  {course.code}: {course.title}
                </h3>
                <p className="mt-2 text-neutral-600">
                  {course.description}
                </p>
                <div className="mt-4 text-sm text-neutral-500">
                  <div className="flex items-center">
                    <CalendarIcon className="text-neutral-400 mr-1 h-4 w-4" />
                    <span>Semester: {course.semester}</span>
                  </div>
                  <div className="flex items-center mt-1">
                    <Clock className="text-neutral-400 mr-1 h-4 w-4" />
                    <span>{course.schedule}</span>
                  </div>
                </div>
                <div className="mt-4 space-y-2">
                  <a 
                    href={course.syllabusLink}
                    className="flex items-center text-[#0B6623] hover:text-[#094d1c]"
                  >
                    <FileDown className="mr-1 h-4 w-4" />
                    <span>Download Syllabus</span>
                  </a>
                  <a 
                    href={course.materialsLink}
                    className="flex items-center text-[#0B6623] hover:text-[#094d1c]"
                  >
                    <FileDown className="mr-1 h-4 w-4" />
                    <span>Course Materials</span>
                  </a>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="mt-12">
          <h3 className="text-2xl font-semibold font-georgia text-neutral-900">Office Hours</h3>
          <p className="mt-2 text-neutral-600">
            I am available to meet with students during the following hours, or by appointment.
          </p>
          
          <Card className="mt-6 bg-neutral-50 border border-neutral-200">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-neutral-900">Regular Office Hours</h4>
                  <ul className="mt-2 space-y-2 text-neutral-700">
                    <li className="flex items-center">
                      <Clock className="text-[#0B6623] mr-2 h-4 w-4" />
                      <span>Mondays: 1:00pm - 3:00pm</span>
                    </li>
                    <li className="flex items-center">
                      <Clock className="text-[#0B6623] mr-2 h-4 w-4" />
                      <span>Thursdays: 10:00am - 12:00pm</span>
                    </li>
                  </ul>
                  <p className="mt-4 text-neutral-600">
                    Office: Faculty of Education Building, Room 245
                  </p>
                </div>
                
                <div>
                  <h4 className="font-medium text-neutral-900">Book an Appointment</h4>
                  <p className="mt-2 text-neutral-600">
                    If you cannot make it during regular office hours, please schedule an appointment.
                  </p>
                  <Button 
                    asChild 
                    className="mt-4 bg-[#0B6623] hover:bg-[#094d1c]"
                  >
                    <Link href="/contact">
                      Request Appointment
                    </Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default TeachingPage;
