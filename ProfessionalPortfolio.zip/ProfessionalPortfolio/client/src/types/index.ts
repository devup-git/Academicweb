// User types
export interface User {
  id: number;
  username: string;
  email: string;
  fullName: string;
  role: 'student' | 'admin';
  studentId?: string;
}

export interface UserCredentials {
  username: string;
  password: string;
}

// Publication type
export interface Publication {
  id: number;
  title: string;
  year: number;
  description: string;
  tags: string[];
  pdfLink?: string;
  doiLink?: string;
  authors?: string;
  venue?: string;
  citationCount?: number;
}

// Research area type
export interface ResearchArea {
  id: number;
  title: string;
  description: string;
  icon: string;
  topics: string[];
}

// Course type
export interface Course {
  id: number;
  code: string;
  title: string;
  description: string;
  semester: string;
  schedule: string;
  syllabusLink: string;
  materialsLink: string;
  isActive?: boolean;
  password?: string;
}

// Resource type
export interface Resource {
  id: number;
  title: string;
  description: string;
  type: 'student' | 'tool';
  icon: string;
  link: string;
  isExternal?: boolean;
}

// Featured item type
export interface FeaturedItem {
  id: number;
  title: string;
  description: string;
  icon: string;
  linkText: string;
  linkUrl: string;
}

// Contact form data
export interface ContactFormData {
  name: string;
  email: string;
  subject: string;
  message: string;
}

// Online Learning Types
export interface Lesson {
  id: number;
  courseId: number;
  title: string;
  description?: string;
  videoUrl?: string;
  recordedUrl?: string;
  zoomLink?: string;
  startDate?: Date;
  endDate?: Date;
}

export interface CourseMaterial {
  id: number;
  courseId: number;
  lessonId?: number;
  title: string;
  description?: string;
  fileUrl: string;
  contentType: 'image' | 'video' | 'document';
}

export interface Exam {
  id: number;
  courseId: number;
  title: string;
  description?: string;
  startDate: Date;
  endDate: Date;
  duration: number; // in minutes
  isPublished: boolean;
  randomizeQuestions: boolean;
}

export interface ExamQuestion {
  id: number;
  examId: number;
  questionText: string;
  questionType: 'multiple_choice' | 'short_answer' | 'essay';
  options?: string[];
  correctAnswer?: string;
  points: number;
}

export interface ExamSubmission {
  id: number;
  examId: number;
  userId: number;
  startedAt: Date;
  submittedAt?: Date;
  score?: number;
  isGraded: boolean;
}

export interface ExamAnswer {
  id: number;
  submissionId: number;
  questionId: number;
  answerText?: string;
  isCorrect?: boolean;
  points?: number;
  feedback?: string;
}

// News Types
export interface NewsPost {
  id: number;
  title: string;
  content: string;
  summary: string;
  imageUrl?: string;
  publishedAt: Date;
  updatedAt: Date;
  tags?: string[];
}

// Gallery Types
export interface GalleryImage {
  id: number;
  title: string;
  description?: string;
  imageUrl: string;
  thumbnailUrl: string;
  category?: string;
  uploadedAt: Date;
}
