import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactMessageSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Endpoints
  
  // Contact form submission
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactMessageSchema.parse(req.body);
      // Since we're using memory storage, we'll just log the message
      // In a real app, this would be stored in the database
      console.log("Contact form submission:", validatedData);
      
      res.status(200).json({ 
        success: true, 
        message: "Message received successfully. Thank you for contacting Dr. Ashaver." 
      });
    } catch (error) {
      console.error("Contact form error:", error);
      res.status(400).json({ 
        success: false, 
        message: "Invalid form data. Please check your submission and try again." 
      });
    }
  });

  // Download endpoint for CV and course materials
  app.get("/api/downloads/:filename", (req, res) => {
    const { filename } = req.params;
    
    // In a real implementation, we would serve actual files
    // But for this demo, we'll just acknowledge the request
    res.status(200).json({ 
      success: true, 
      message: `Request for ${filename} received. This would download the file in production.` 
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
